-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 13, 2011 at 06:56 PM
-- Server version: 5.1.50
-- PHP Version: 5.2.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `legedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `alcance`
--

DROP TABLE IF EXISTS `alcance`;
CREATE TABLE IF NOT EXISTS `alcance` (
  `id_alcance` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `ver_todos_registros` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_alcance`,`id_usuario`),
  KEY `FI_empresa_alcance` (`id_empresa`),
  KEY `FI_tabla_alcance` (`id_tabla`),
  KEY `FI_usuario_alcance` (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `alcance`
--

INSERT INTO `alcance` (`id_alcance`, `id_usuario`, `id_empresa`, `id_tabla`, `titulo`, `descripcion`, `ver_todos_registros`, `created_at`, `updated_at`) VALUES
(1, 2, 0, 0, 'Todo de todos', NULL, 1, '2009-02-04 18:14:19', '2009-02-04 18:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `campo`
--

DROP TABLE IF EXISTS `campo`;
CREATE TABLE IF NOT EXISTS `campo` (
  `id_campo` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `es_general` tinyint(4) DEFAULT NULL,
  `es_nombre` int(1) DEFAULT NULL,
  `nombre` varchar(150) DEFAULT NULL,
  `descripcion` text,
  `tipo` int(11) DEFAULT NULL,
  `misma_fila` tinyint(4) DEFAULT '0',
  `en_lista` tinyint(4) NOT NULL DEFAULT '0',
  `desplegable` tinyint(4) DEFAULT '0',
  `seleccion_multiple` tinyint(4) DEFAULT NULL,
  `tipo_items` int(11) DEFAULT NULL,
  `unidad_rangos` varchar(10) DEFAULT NULL,
  `tipo_periodo` int(11) DEFAULT NULL,
  `valor_tabla` int(11) DEFAULT NULL,
  `mostrar_en_padre` tinyint(4) DEFAULT NULL,
  `valor_objeto` varchar(250) DEFAULT NULL,
  `defecto` varchar(250) DEFAULT NULL,
  `obligatorio` tinyint(4) DEFAULT NULL,
  `es_cod_agencia` int(11) DEFAULT NULL,
  `tamano` varchar(250) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `es_inconsistente` tinyint(4) DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_campo`),
  KEY `FI_campo_empresa` (`id_empresa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=262 ;

--
-- Dumping data for table `campo`
--

INSERT INTO `campo` (`id_campo`, `id_empresa`, `es_general`, `es_nombre`, `nombre`, `descripcion`, `tipo`, `misma_fila`, `en_lista`, `desplegable`, `seleccion_multiple`, `tipo_items`, `unidad_rangos`, `tipo_periodo`, `valor_tabla`, `mostrar_en_padre`, `valor_objeto`, `defecto`, `obligatorio`, `es_cod_agencia`, `tamano`, `orden`, `es_inconsistente`, `borrado`) VALUES
(39, 10, 0, 1, 'Fichero', '', 6, 0, 0, 0, 0, 1, NULL, 1, 5, 1, NULL, '', 1, 0, NULL, 2, 0, 0),
(37, 10, 0, 0, 'Codigo Agencia', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 1, '12', 34, 0, 0),
(38, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', '', 1, 0, NULL, 17, 0, 0),
(36, 10, 0, 0, 'Nivel', '', 4, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 26, 0, 0),
(35, 10, 0, 0, 'Finalidad', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 18, NULL, 0),
(34, 10, 0, 1, 'Nombre', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 4, 0, 0),
(33, 10, 0, 1, 'Departamento', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 6, NULL, 0),
(40, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, NULL, '1', 1, 0, NULL, 27, 0, 0),
(41, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, NULL, '0', 0, 0, NULL, 35, 0, 0),
(42, 10, 0, 0, 'Autorizado por', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', NULL, NULL, 0, NULL, 41, NULL, 0),
(43, 10, 0, 1, 'Recurso', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 8, NULL, 0),
(44, 10, 0, 1, 'Soporte', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 19, NULL, 0),
(45, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 28, NULL, 0),
(46, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 36, NULL, 0),
(47, 10, 0, 1, 'Recurso', '', 6, 0, 0, 0, 0, 1, NULL, 1, 9, 1, NULL, '65', 0, 0, NULL, 10, 0, 0),
(48, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, 4, NULL, 'Usuario', NULL, NULL, 0, NULL, 20, 0, 0),
(49, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 29, NULL, 0),
(50, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 37, NULL, 0),
(51, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', NULL, NULL, 0, NULL, 21, NULL, 0),
(52, 10, 0, 0, 'Fecha', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 30, NULL, 0),
(53, 10, 0, 0, 'Destinatario', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 38, 0, 0),
(54, 10, 0, 0, 'Fecha Resolucion', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 42, NULL, 0),
(69, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', NULL, 0, 0, NULL, 46, NULL, NULL),
(56, 10, 0, 1, 'Asunto', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 12, NULL, 0),
(57, 10, 0, 0, 'Descripción', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 47, NULL, 0),
(62, 10, 0, 1, 'Departamento', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 26, NULL, 0),
(64, 10, 0, 0, 'Incidencia', '', 6, 0, 0, 0, 0, 1, NULL, 1, 8, 1, NULL, NULL, 0, 0, NULL, 13, NULL, NULL),
(65, 10, 0, 1, 'Nombre', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, 0, NULL, 22, NULL, NULL),
(66, 10, 0, 0, 'Descripción', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 31, NULL, NULL),
(67, 10, 0, 0, 'Ha solucionado el problema?', '', 4, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 39, NULL, NULL),
(68, 10, 0, 0, 'Fecha Acción', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, 0, NULL, 43, NULL, NULL),
(70, 10, 0, 0, 'Encargado del fichero', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', '', 0, 0, NULL, 44, 0, NULL),
(73, 10, 0, 0, 'Causa de la baja', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 45, NULL, NULL),
(71, 10, 0, 0, 'Responsable', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', '', 0, 0, NULL, 48, 0, NULL),
(72, 10, 0, 0, 'Código', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 14, NULL, NULL),
(74, 10, 0, 0, 'Tipo recurso', '', 4, 0, 1, 1, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 23, NULL, NULL),
(75, 10, 0, 0, 'Persona', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', NULL, 0, 0, NULL, 49, NULL, NULL),
(77, 10, 0, 0, 'Fecha Formación', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, 0, NULL, 50, NULL, NULL),
(78, 10, 0, 0, 'Autorizado', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', NULL, 0, 0, NULL, 32, NULL, NULL),
(79, 10, 0, 0, 'Fecha Alta', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, 0, NULL, 15, NULL, NULL),
(80, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '0', 0, 0, NULL, 24, NULL, NULL),
(81, 10, 0, 0, 'Copia Seguridad realizada?', '', 3, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 25, NULL, NULL),
(82, 10, 0, 0, 'Fecha', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, 0, NULL, 16, NULL, NULL),
(83, 10, 0, 0, 'Encargado', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', NULL, 0, 0, NULL, 33, NULL, NULL),
(84, 10, 0, 0, 'Copia verificada', '', 3, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 40, NULL, NULL),
(254, 10, 0, 0, 'Fecha caducidad', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 1, NULL, '0', 0, NULL, NULL, 87, 0, NULL),
(160, 10, 0, 0, 'Descripción', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 48, NULL, NULL),
(159, 10, 0, 1, 'Nombre', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, 0, NULL, 31, NULL, NULL),
(158, 10, 0, 0, 'Incidencia', '', 6, 0, 0, 0, 0, 1, NULL, 1, 8, 1, NULL, NULL, 0, 0, NULL, 11, NULL, NULL),
(157, 10, 0, 0, 'Causa de la baja', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 76, NULL, NULL),
(156, 10, 0, 0, 'Código', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 12, NULL, NULL),
(155, 10, 0, 0, 'Responsable', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', '', 0, 0, NULL, 83, 0, NULL),
(154, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 64, NULL, 0),
(153, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 49, NULL, 0),
(152, 10, 0, 1, 'Soporte', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 32, NULL, 0),
(151, 10, 0, 0, 'Tipo recurso', '', 4, 0, 1, 1, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 33, NULL, NULL),
(150, 10, 0, 1, 'Recurso', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 13, NULL, 0),
(149, 10, 0, 0, 'Descripción', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 84, NULL, 0),
(148, 10, 0, 1, 'Asunto', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 14, NULL, 0),
(147, 10, 0, 0, 'Fecha Resolucion', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 77, NULL, 0),
(146, 10, 0, 0, 'Destinatario', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 65, 0, 0),
(145, 10, 0, 0, 'Fecha', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 50, NULL, 0),
(144, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', NULL, NULL, 0, NULL, 34, NULL, 0),
(143, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 66, NULL, 0),
(142, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 51, NULL, 0),
(141, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, 4, NULL, 'Usuario', NULL, NULL, 0, NULL, 35, 0, 0),
(140, 10, 0, 1, 'Recurso', '', 6, 0, 0, 0, 0, 1, NULL, 1, 9, 1, NULL, '65', 0, 0, NULL, 15, 0, 0),
(139, 10, 0, 0, 'Autorizado por', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', NULL, NULL, 0, NULL, 78, NULL, 0),
(138, 10, 0, 0, 'Fecha Baja', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, NULL, '0', 0, 0, NULL, 67, 0, 0),
(137, 10, 0, 0, 'Fecha Alta', '', 9, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, NULL, '1', 1, 0, NULL, 52, 0, 0),
(136, 10, 0, 1, 'Fichero', '', 6, 0, 0, 0, 0, 1, NULL, 1, 5, 1, NULL, '', 1, 0, NULL, 16, 0, 0),
(135, 10, 0, 0, 'Usuario', '', 7, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 'Usuario', '', 1, 0, NULL, 36, 0, 0),
(134, 10, 0, 1, 'Departamento', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 17, NULL, 0),
(133, 10, 0, 0, 'Encargado del fichero', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Usuario', '', 0, 0, NULL, 79, 0, NULL),
(132, 10, 0, 0, 'Codigo Agencia', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 68, 0, 0),
(131, 10, 0, 0, 'Nivel', '', 4, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, 0, NULL, 53, 0, 0),
(130, 10, 0, 0, 'Finalidad', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, '', NULL, NULL, 0, NULL, 37, NULL, 0),
(129, 10, 0, 1, 'Nombre', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, 0, NULL, 18, 0, 0),
(253, 10, 0, 0, 'Firma', '', 3, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 86, NULL, NULL),
(252, 10, 0, 0, 'Lugar', '', 1, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, NULL, NULL, 85, NULL, NULL),
(251, 10, 0, 0, 'Fecha firma', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, NULL, NULL, 84, NULL, NULL),
(250, 10, 0, 0, 'Contrato', '', 10, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 83, NULL, NULL),
(249, 10, 0, 1, 'Servicio', '', 6, 0, 1, 0, 0, 1, NULL, 1, 57, 0, NULL, NULL, 1, NULL, NULL, 82, NULL, NULL),
(248, 10, 0, 1, 'Encargado tratamiento', '', 7, 0, 1, 0, 0, 1, NULL, 1, 55, 0, 'Encargado', NULL, 1, NULL, NULL, 81, 0, NULL),
(247, 10, 0, 0, 'Comunicado personal medidas seguridad', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, NULL, NULL, 80, NULL, NULL),
(246, 10, 0, 0, 'Fecha inicio', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, NULL, NULL, 79, NULL, NULL),
(245, 10, 0, 1, 'Servicio', '', 6, 0, 1, 0, 0, 1, NULL, 1, 57, 0, NULL, NULL, 1, NULL, NULL, 78, NULL, NULL),
(244, 10, 0, 1, 'Encargado', '', 7, 0, 1, 0, 0, 1, NULL, 1, 55, 0, 'Encargado', NULL, 1, NULL, NULL, 77, 0, NULL),
(243, 10, 0, 0, 'Fichero Contestación', '', 10, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 76, NULL, NULL),
(242, 10, 0, 0, 'Observaciones', '', 2, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, NULL, NULL, 75, NULL, NULL),
(241, 10, 0, 0, 'Fecha contestación', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '0', 0, NULL, NULL, 74, NULL, NULL),
(240, 10, 0, 0, 'Fecha de ejercicio', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 1, NULL, NULL, 73, NULL, NULL),
(239, 10, 0, 1, 'Derechos', '', 4, 0, 1, 0, 1, 1, NULL, 1, NULL, 0, NULL, NULL, 1, NULL, NULL, 72, NULL, NULL),
(238, 10, 0, 1, 'Encargado tratamiento', '', 7, 0, 1, 0, 0, 1, NULL, 1, 55, 0, 'Encargado', NULL, 1, NULL, NULL, 71, 0, NULL),
(237, 10, 0, 0, 'Documento', '', 10, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 70, 0, NULL),
(236, 10, 0, 0, 'Destrucción información', '', 3, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 69, NULL, NULL),
(235, 10, 0, 0, 'Devolución información', '', 3, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 68, NULL, NULL),
(234, 10, 0, 0, 'Fecha Baja', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '0', 0, NULL, NULL, 67, NULL, NULL),
(233, 10, 0, 1, 'Fecha alta', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 1, NULL, NULL, 66, 0, NULL),
(232, 10, 0, 1, 'Encargado tratamiento', '', 7, 0, 1, 0, 0, 1, NULL, 1, 55, 0, 'Encargado', NULL, 1, NULL, NULL, 65, 0, NULL),
(231, 10, 0, 0, 'Autorización o contrato', '', 10, 0, 0, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 64, NULL, NULL),
(230, 10, 0, 1, 'Subcontratante', '', 1, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, NULL, NULL, 63, NULL, NULL),
(229, 10, 0, 0, 'Servicio', '', 6, 0, 1, 0, 0, 1, NULL, 1, 57, 0, NULL, NULL, 0, NULL, NULL, 62, NULL, NULL),
(228, 10, 0, 0, 'Autorizada', '', 3, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 61, NULL, NULL),
(227, 10, 0, 1, 'Encargado tratamiento', '', 7, 0, 1, 0, 0, 1, NULL, 1, 55, 0, 'Encargado', NULL, 1, NULL, NULL, 60, 0, NULL),
(226, 10, 0, 0, 'Auditoria', '', 3, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 59, NULL, NULL),
(225, 10, 0, 0, 'Medidas de seguridad', '', 4, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 58, NULL, NULL),
(224, 10, 0, 0, 'Trata datos', '', 3, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 0, NULL, NULL, 57, NULL, NULL),
(223, 10, 0, 1, 'Encargado tratamiento', '', 7, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, 'Encargado', '', 1, NULL, NULL, 56, 0, NULL),
(222, 10, 0, 0, 'Fecha Fin', '', 9, 0, 1, 0, 0, 1, NULL, 2, NULL, 1, NULL, '5', 0, NULL, NULL, 55, 0, NULL),
(221, 10, 0, 0, 'Fecha Inicio', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, NULL, NULL, 54, NULL, NULL),
(220, 10, 0, 0, 'Empresa', '', 1, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, NULL, NULL, 53, 0, NULL),
(219, 10, 0, 1, 'Servicio', '', 1, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, NULL, NULL, 52, NULL, NULL),
(218, 10, 0, 0, 'Documento', '', 10, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 51, NULL, NULL),
(255, 10, 0, 0, 'DocumentoAuditoria', '', 10, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 88, NULL, NULL),
(256, 10, 0, 1, 'Descripcion', '', 1, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '', 1, NULL, NULL, 3, NULL, NULL),
(257, 10, 0, 0, 'Prioridad', '', 4, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, NULL, 1, NULL, NULL, 5, 1, NULL),
(258, 10, 0, 0, 'Fecha Alta', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '1', 0, NULL, NULL, 7, NULL, NULL),
(259, 10, 0, 0, 'Fecha Prevista Realizacion', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 1, NULL, '5', 1, NULL, NULL, 9, NULL, NULL),
(260, 10, 0, 0, 'Fecha realización', '', 9, 0, 1, 0, 0, 1, NULL, 1, NULL, 0, NULL, '0', 0, NULL, NULL, 11, NULL, NULL),
(261, 10, 0, 1, 'Auditoria', '', 6, 0, 1, 0, 0, 1, NULL, 1, 55, 1, NULL, '', 1, NULL, NULL, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `catalogue`
--

DROP TABLE IF EXISTS `catalogue`;
CREATE TABLE IF NOT EXISTS `catalogue` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `nvisible` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `source_lang` varchar(100) DEFAULT NULL,
  `target_lang` varchar(100) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `catalogue`
--

INSERT INTO `catalogue` (`cat_id`, `nvisible`, `name`, `source_lang`, `target_lang`, `date_created`, `date_modified`, `author`) VALUES
(1, 'Castellano', 'messages.es_ES', 'es_ES', 'es_ES', '2008-01-01 00:00:00', '0000-00-00 00:00:00', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nombre` text,
  `razon_social` text,
  `cif` varchar(10) DEFAULT NULL,
  `contacto` text,
  `telefono` varchar(12) DEFAULT NULL,
  `movil` varchar(12) DEFAULT NULL,
  `fax` varchar(12) DEFAULT NULL,
  `domicilio` text,
  `poblacion` varchar(50) DEFAULT NULL,
  `codigo_postal` int(9) DEFAULT NULL,
  `provincia` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `FI_ente_empresa` (`id_empresa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `id_empresa`, `nombre`, `razon_social`, `cif`, `contacto`, `telefono`, `movil`, `fax`, `domicilio`, `poblacion`, `codigo_postal`, `provincia`) VALUES
(1, 10, 'Neofis, Nuevas Tecnologías', '', '', NULL, '', '', '', '', '', 0, ''),
(2, 10, 'Seinale', 'Seinale, S.L.', 'B20854840', 'Andoni García Imaz', '943320792', '', '', 'Calle Egia 19,Local 3', 'Donostia', 20012, 'Gipuzkoa');

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
CREATE TABLE IF NOT EXISTS `empresa` (
  `id_empresa` int(11) NOT NULL AUTO_INCREMENT,
  `id_provincia` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_actividad` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domicilio` text COLLATE utf8_unicode_ci,
  `poblacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cif` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_min` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_med` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_max` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_vtiger` int(11) DEFAULT NULL,
  `smtp_server` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_user` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smtp_port` int(11) DEFAULT NULL,
  `sender_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sender_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_letra1` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_letra2` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_letra3` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_letra4` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_empresa`),
  KEY `FI_empresa_provincia` (`id_provincia`),
  KEY `FI_usuario_empresa` (`id_usuario`),
  KEY `FI_empresa_actividad` (`id_actividad`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`id_empresa`, `id_provincia`, `id_usuario`, `nombre`, `id_actividad`, `telefono`, `fax`, `email`, `domicilio`, `poblacion`, `codigo_postal`, `cif`, `logo_min`, `logo_med`, `logo_max`, `id_vtiger`, `smtp_server`, `smtp_user`, `smtp_password`, `smtp_port`, `sender_address`, `sender_name`, `color1`, `color2`, `color3`, `color4`, `color_letra1`, `color_letra2`, `color_letra3`, `color_letra4`, `created_at`, `updated_at`, `borrado`) VALUES
(10, 1, 2, 'ESLE', 'N14', '000000000', '000000000', '-', '-', '-', '000000', '123456789N', NULL, NULL, NULL, NULL, '', '', '', '', '', 'Legedia', '#FFFFFF', '#EAEAF4', '#3D4584', '#FFFEF2', '#000000', '#FFFFFF', '#333333', '#666666', '2009-05-22 08:50:26', '2010-08-25 16:51:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `formulario`
--

DROP TABLE IF EXISTS `formulario`;
CREATE TABLE IF NOT EXISTS `formulario` (
  `id_formulario` int(11) NOT NULL AUTO_INCREMENT,
  `id_tabla` int(11) NOT NULL,
  `id_usuario_creador` int(11) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_formulario`),
  KEY `FI_tabla_formulario` (`id_tabla`),
  KEY `FI_usuario_formulario` (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=178 ;

--
-- Dumping data for table `formulario`
--

INSERT INTO `formulario` (`id_formulario`, `id_tabla`, `id_usuario_creador`, `id_usuario`, `fecha`, `created_at`, `updated_at`) VALUES
(127, 59, 2, 2, '2010-10-27 13:47:00', '2010-08-05 16:52:30', '2010-10-27 13:47:00'),
(128, 57, 2, 2, '2010-08-17 14:45:45', '2010-08-17 14:40:11', '2010-08-17 14:45:45'),
(129, 57, NULL, 2, '2010-08-24 12:02:30', '2010-08-23 16:52:43', '2010-08-24 12:02:30'),
(131, 59, NULL, 2, '2010-09-09 11:11:59', '2010-09-09 11:11:30', '2010-09-09 11:11:59'),
(132, 57, NULL, 2, '2010-09-09 11:14:05', '2010-09-09 11:13:51', '2010-09-09 11:14:05'),
(175, 62, NULL, 2, '2010-09-09 20:29:15', '2010-09-09 20:29:02', '2010-09-09 20:29:15'),
(161, 58, NULL, 2, '2010-09-09 12:52:30', '2010-09-09 12:52:30', '2010-09-09 12:52:30'),
(176, 55, NULL, 2, '2010-10-27 14:11:21', '2010-10-27 13:26:02', '2010-10-27 14:11:21'),
(177, 63, NULL, 2, '2010-10-27 19:21:28', '2010-10-27 18:28:22', '2010-10-27 19:21:29');

-- --------------------------------------------------------

--
-- Table structure for table `grupo`
--

DROP TABLE IF EXISTS `grupo`;
CREATE TABLE IF NOT EXISTS `grupo` (
  `id_grupo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `padre` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_grupo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `grupo`
--

INSERT INTO `grupo` (`id_grupo`, `nombre`, `padre`) VALUES
(1, 'Administradores', 2),
(2, 'Invitados', 0),
(3, 'Usuarios', 2);

-- --------------------------------------------------------

--
-- Table structure for table `grupo_modulo`
--

DROP TABLE IF EXISTS `grupo_modulo`;
CREATE TABLE IF NOT EXISTS `grupo_modulo` (
  `modulo` varchar(50) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `id_grupo` int(11) NOT NULL,
  `permiso` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`modulo`,`accion`,`id_grupo`),
  KEY `FI_grupo_modulo_grupo` (`id_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grupo_modulo`
--

INSERT INTO `grupo_modulo` (`modulo`, `accion`, `id_grupo`, `permiso`) VALUES
('login', 'logout', 2, 1),
('login', 'logindni', 2, 1),
('login', 'login', 2, 1),
('tareas', 'mostrarllamada', 1, 1),
('tareas', 'cambiar_estado', 1, 1),
('tareas', 'delete', 1, 1),
('tareas', 'edit', 1, 1),
('tareas', 'save', 1, 1),
('tareas', 'create', 1, 1),
('tareas', 'list', 1, 1),
('tareas', 'show', 1, 1),
('tareas', 'index', 1, 1),
('tablas', 'subir', 1, 1),
('tablas', 'bajar', 1, 1),
('tablas', 'delete', 1, 1),
('tablas', 'duplicate', 1, 1),
('tablas', 'edit', 1, 1),
('tablas', 'save', 1, 1),
('tablas', 'create', 1, 1),
('tablas', 'list', 1, 1),
('tablas', 'show', 1, 1),
('tablas', 'index', 1, 1),
('sftransunit', 'delete', 1, 1),
('sftransunit', 'edit', 1, 1),
('sftransunit', 'save', 1, 1),
('sftransunit', 'create', 1, 1),
('sftransunit', 'list', 1, 1),
('sftransunit', 'index', 1, 1),
('sfcatalogue', 'delete', 1, 1),
('sfcatalogue', 'edit', 1, 1),
('sfcatalogue', 'save', 1, 1),
('sfcatalogue', 'create', 1, 1),
('sfcatalogue', 'list', 1, 1),
('sfcatalogue', 'index', 1, 1),
('sesioneslog', 'delete', 1, 1),
('sesioneslog', 'show', 1, 1),
('sesioneslog', 'list', 1, 1),
('sesioneslog', 'index', 1, 1),
('preferencias', 'save', 3, 1),
('preferencias', 'edit', 3, 1),
('preferencias', 'show', 3, 1),
('preferencias', 'index', 3, 1),
('panel', 'cambiarcalendario', 3, 1),
('panel', 'empresa_sesion', 3, 1),
('mensajes', 'delete_entrada', 3, 1),
('mensajes', 'entrada', 3, 1),
('mensajes', 'salida', 3, 1),
('panel', 'index', 3, 1),
('sesiones', 'delete', 1, 1),
('sesiones', 'list', 1, 1),
('sesiones', 'index', 1, 1),
('preferencias', 'save', 1, 1),
('preferencias', 'edit', 1, 1),
('parametros', 'order_item', 1, 1),
('parametros', 'reorder_items', 1, 1),
('mensajes', 'delete_salida', 3, 1),
('mensajes', 'leer', 3, 1),
('mensajes', 'edit', 3, 1),
('mensajes', 'save', 3, 1),
('mensajes', 'create', 3, 1),
('mensajes', 'index', 3, 1),
('login', 'logout', 3, 1),
('preferencias', 'show', 1, 1),
('preferencias', 'index', 1, 1),
('login', 'index', 2, 1),
('content', 'bugreport', 2, 1),
('content', 'about', 2, 1),
('parametros', 'enable_item', 1, 1),
('formularios', 'delete', 3, 1),
('formularios', 'edit', 3, 1),
('formularios', 'createpopup', 3, 1),
('formularios', 'editpopup', 3, 1),
('formularios', 'save', 3, 1),
('formularios', 'create', 3, 1),
('formularios', 'excel', 3, 1),
('formularios', 'csv', 3, 1),
('formularios', 'popup', 3, 1),
('formularios', 'list', 3, 1),
('formularios', 'index', 3, 1),
('parametros', 'download', 1, 1),
('parametros', 'delete_item', 1, 1),
('parametros', 'edit_item', 1, 1),
('parametros', 'show_item', 1, 1),
('parametros', 'create_item', 1, 1),
('parametros', 'show', 1, 1),
('parametros', 'list', 1, 1),
('parametros', 'index', 1, 1),
('panel', 'cambiarcalendario', 1, 1),
('panel', 'empresa_sesion', 1, 1),
('panel', 'index', 1, 1),
('notificaciones', 'guardar_modificacion', 1, 1),
('notificaciones', 'parar', 1, 1),
('notificaciones', 'guardar_empezar_proceso', 1, 1),
('notificaciones', 'suprimir', 1, 1),
('notificaciones', 'modificar', 1, 1),
('notificaciones', 'inscribir', 1, 1),
('notificaciones', 'consultar', 1, 1),
('notificaciones', 'index', 1, 1),
('mensajes', 'salida', 1, 1),
('mensajes', 'entrada', 1, 1),
('mensajes', 'delete_entrada', 1, 1),
('mensajes', 'delete_salida', 1, 1),
('mensajes', 'leer', 1, 1),
('mensajes', 'edit', 1, 1),
('mensajes', 'save', 1, 1),
('mensajes', 'create', 1, 1),
('mensajes', 'index', 1, 1),
('login', 'logout', 1, 1),
('login', 'login', 1, 1),
('login', 'index', 1, 1),
('grupos', 'delete', 1, 1),
('grupos', 'edit', 1, 1),
('grupos', 'save', 1, 1),
('grupos', 'create', 1, 1),
('grupos', 'list', 1, 1),
('grupos', 'show', 1, 1),
('grupos', 'index', 1, 1),
('formularios', 'delete', 1, 1),
('formularios', 'edit', 1, 1),
('formularios', 'createpopup', 1, 1),
('formularios', 'editpopup', 1, 1),
('formularios', 'save', 1, 1),
('formularios', 'create', 1, 1),
('formularios', 'download', 1, 1),
('formularios', 'excel', 1, 1),
('formularios', 'csv', 1, 1),
('formularios', 'popup', 1, 1),
('formularios', 'index', 1, 1),
('formularios', 'list', 1, 1),
('formulario_modelo', 'html_formulario', 1, 1),
('formulario_modelo', 'consolidar_formularios', 1, 1),
('formulario_modelo', 'actualizar_formulario_modelo', 1, 1),
('formulario_modelo', 'ordenar_item', 1, 1),
('formulario_modelo', 'delete_item', 1, 1),
('formulario_modelo', 'edit_item', 1, 1),
('formulario_modelo', 'create_item', 1, 1),
('formulario_modelo', 'ordenar_campo', 1, 1),
('formulario_modelo', 'undelete_campo', 1, 1),
('formulario_modelo', 'delete_campo', 1, 1),
('formulario_modelo', 'edit_campo', 1, 1),
('formulario_modelo', 'show_campo', 1, 1),
('formulario_modelo', 'create_campo', 1, 1),
('formulario_modelo', 'edit', 1, 1),
('encargados', 'delete', 1, 1),
('encargados', 'edit', 1, 1),
('encargados', 'save', 1, 1),
('encargados', 'create', 1, 1),
('encargados', 'list', 1, 1),
('encargados', 'show', 1, 1),
('encargados', 'index', 1, 1),
('empresas', 'edit_email', 1, 1),
('empresas', 'cambiar', 1, 1),
('empresas', 'upload_logo', 1, 1),
('empresas', 'update_select_tablas2', 1, 1),
('empresas', 'update_select_tablas', 1, 1),
('empresas', 'delete', 1, 1),
('empresas', 'duplicate', 1, 1),
('empresas', 'edit', 1, 1),
('empresas', 'save', 1, 1),
('empresas', 'list', 1, 1),
('empresas', 'create', 1, 1),
('empresas', 'show', 1, 1),
('empresas', 'index', 1, 1),
('backups', 'subir', 1, 1),
('backups', 'borrar', 1, 1),
('backups', 'restaurar', 1, 1),
('backups', 'generar', 1, 1),
('backups', 'list', 1, 1),
('backups', 'index', 1, 1),
('alcance', 'update_selects', 1, 1),
('alcance', 'delete', 1, 1),
('alcance', 'edit', 1, 1),
('alcance', 'save', 1, 1),
('alcance', 'create', 1, 1),
('alcance', 'list', 1, 1),
('content', 'index', 2, 1),
('usuarios', 'index', 1, 1),
('usuarios', 'show', 1, 1),
('usuarios', 'list', 1, 1),
('usuarios', 'create', 1, 1),
('usuarios', 'save', 1, 1),
('usuarios', 'edit', 1, 1),
('usuarios', 'delete', 1, 1),
('tareas', 'enviar_alarmas', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_formulario` int(11) NOT NULL,
  `id_item_base` int(11) NOT NULL,
  `texto_corto` varchar(255) DEFAULT NULL,
  `texto_largo` text,
  `si_no` tinyint(4) DEFAULT NULL,
  `texto_auxiliar` varchar(255) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `id_tabla` int(11) DEFAULT NULL,
  `id_objeto` int(11) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_item`,`id_formulario`),
  KEY `FI_item_base_item` (`id_item_base`),
  KEY `FI_item_formulario` (`id_formulario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=792 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id_item`, `id_formulario`, `id_item_base`, `texto_corto`, `texto_largo`, `si_no`, `texto_auxiliar`, `fecha`, `numero`, `id_tabla`, `id_objeto`, `anio`) VALUES
(577, 127, 289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL),
(578, 127, 290, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(579, 127, 291, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(580, 127, 292, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(581, 127, 293, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(582, 127, 294, '', NULL, 0, NULL, '2010-08-04 00:00:00', NULL, NULL, NULL, NULL),
(583, 127, 295, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(584, 127, 296, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(585, 127, 297, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(586, 128, 268, 'dasf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(587, 128, 269, 'sdaf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(588, 128, 270, '', NULL, 0, NULL, '2010-08-16 00:00:00', NULL, NULL, NULL, NULL),
(589, 128, 271, NULL, NULL, 1, NULL, '2010-08-31 00:00:00', 1, NULL, NULL, NULL),
(590, 129, 268, 'adsfasdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(591, 129, 269, 'adfs', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(592, 129, 270, '', NULL, 0, NULL, '2010-08-22 00:00:00', NULL, NULL, NULL, NULL),
(593, 129, 271, '1##2##3##4##5', NULL, 1, NULL, '2010-08-31 00:00:00', 2, NULL, NULL, NULL),
(594, 130, 308, '1##3##5', NULL, 1, NULL, '2010-11-30 00:00:00', 2, NULL, NULL, NULL),
(595, 131, 289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(596, 131, 290, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(597, 131, 291, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(598, 131, 292, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(599, 131, 293, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(600, 131, 294, '', NULL, 0, NULL, '2010-09-08 00:00:00', NULL, NULL, NULL, NULL),
(601, 131, 295, '', NULL, 0, NULL, '2010-09-30 00:00:00', NULL, NULL, NULL, NULL),
(602, 131, 296, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(603, 131, 297, '603_administrador.tpl', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(604, 132, 268, 'aaaaaa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(605, 132, 269, 'bbbbb', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(606, 132, 270, '', NULL, 0, NULL, '2010-09-08 00:00:00', NULL, NULL, NULL, NULL),
(607, 132, 271, '2##4', NULL, 1, NULL, '2010-09-30 00:00:00', 2, NULL, NULL, NULL),
(608, 133, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(609, 133, 303, NULL, NULL, NULL, NULL, NULL, NULL, 132, NULL, NULL),
(610, 133, 304, '610_datos.txt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(611, 133, 305, '', NULL, 0, NULL, '2010-09-13 00:00:00', NULL, NULL, NULL, NULL),
(612, 133, 306, 'eee', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(613, 133, 307, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(614, 133, 308, '', NULL, 0, NULL, '2010-09-08 00:00:00', 2, NULL, NULL, NULL),
(780, 175, 308, '4##5', NULL, 1, NULL, '2010-09-30 00:00:00', 2, NULL, NULL, NULL),
(779, 175, 307, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(778, 175, 306, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(777, 175, 305, '', NULL, 0, NULL, '2010-09-09 00:00:00', NULL, NULL, NULL, NULL),
(776, 175, 304, '776_administrador.tpl', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(775, 175, 303, NULL, NULL, NULL, NULL, NULL, NULL, 132, NULL, NULL),
(774, 175, 302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(736, 161, 283, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL),
(737, 161, 284, '', NULL, 0, NULL, '2010-09-08 00:00:00', NULL, NULL, NULL, NULL),
(738, 161, 285, '', NULL, 0, NULL, '2010-09-30 00:00:00', NULL, NULL, NULL, NULL),
(739, 161, 286, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(740, 161, 287, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(741, 161, 288, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(781, 176, 272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL),
(782, 176, 273, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(783, 176, 274, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(784, 176, 277, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(785, 176, 309, '785_proba.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(786, 177, 310, 'asdfasdfafds', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(787, 177, 312, NULL, NULL, 1, '', NULL, NULL, NULL, NULL, NULL),
(788, 177, 314, '', NULL, 0, NULL, '2010-10-26 00:00:00', NULL, NULL, NULL, NULL),
(789, 177, 315, '1##2##3', NULL, 1, NULL, '2010-12-16 00:00:00', 2, NULL, NULL, NULL),
(790, 177, 316, '', NULL, 0, NULL, '2010-11-28 00:00:00', NULL, NULL, NULL, NULL),
(791, 177, 317, NULL, NULL, NULL, NULL, NULL, NULL, 176, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `item_base`
--

DROP TABLE IF EXISTS `item_base`;
CREATE TABLE IF NOT EXISTS `item_base` (
  `id_item_base` int(11) NOT NULL AUTO_INCREMENT,
  `id_campo` int(11) NOT NULL,
  `texto` varchar(150) DEFAULT NULL,
  `numero_inferior` float DEFAULT NULL,
  `numero_superior` float DEFAULT NULL,
  `ayuda` text,
  `texto_auxiliar` tinyint(4) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `es_responsable_fichero` int(11) DEFAULT NULL,
  `es_inconsistente` tinyint(4) DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_item_base`),
  KEY `FI_campo_item` (`id_campo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=318 ;

--
-- Dumping data for table `item_base`
--

INSERT INTO `item_base` (`id_item_base`, `id_campo`, `texto`, `numero_inferior`, `numero_superior`, `ayuda`, `texto_auxiliar`, `orden`, `es_responsable_fichero`, `es_inconsistente`, `borrado`) VALUES
(59, 43, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(58, 42, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(57, 41, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(56, 40, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(55, 39, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(54, 38, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(53, 37, NULL, NULL, NULL, '<p>Dato proporcionado por la APD, como m&aacute;ximo 30 d&iacute;as despu&eacute;s de la notificaci&oacute;n del fichero. </p><p>Consta de 10 digitos: 3 para el a&ntilde;o sin el primer cero, 3 para el d&iacute;a dentro del a&ntilde;o y 4 para un n&uacute;mero identificativo. </p><p>Es obligatorio este n&uacute;mero para  poder realizar cualquier modificaci&oacute;n o supresi&oacute;n sobre un fichero. Si ha realizado correctamente todos los pasos de la notificaci&oacute;n y no dispone del mismo pongase en contacto con la APD.</p>', NULL, 1, NULL, 0, 0),
(52, 35, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(51, 34, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(50, 33, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(60, 44, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(61, 45, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(62, 46, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(63, 47, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(64, 48, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(65, 49, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(66, 50, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(67, 51, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(68, 52, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(69, 53, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(70, 54, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(90, 69, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(72, 56, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(73, 57, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(80, 62, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(75, 36, 'Básico', NULL, NULL, '', 0, 1, NULL, 0, 0),
(76, 36, 'Medio', NULL, NULL, '', 0, 2, NULL, 0, 0),
(77, 36, 'Alto', NULL, NULL, '', 0, 3, NULL, 0, 0),
(86, 66, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(85, 65, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(84, 64, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(87, 67, 'Si', NULL, NULL, '', 0, 1, NULL, NULL, NULL),
(88, 67, 'No', NULL, NULL, '', 0, 2, NULL, NULL, NULL),
(89, 68, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(91, 70, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 0),
(92, 71, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(93, 72, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(94, 73, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(95, 74, 'Puesto de trabajo', NULL, NULL, '', 0, 1, NULL, NULL, NULL),
(96, 74, 'Servidor', NULL, NULL, '', 0, 2, NULL, NULL, NULL),
(97, 74, 'Impresora/Fax', NULL, NULL, '', 0, 3, NULL, NULL, NULL),
(98, 74, 'Dispositivo de red', NULL, NULL, '', 0, 4, NULL, NULL, NULL),
(99, 74, 'Otros componentes', NULL, NULL, '', 0, 6, NULL, NULL, NULL),
(100, 74, 'Armarios archivadores', NULL, NULL, '', 0, 5, NULL, NULL, NULL),
(101, 75, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(104, 78, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(103, 77, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(105, 79, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(106, 80, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(107, 81, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(108, 82, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(109, 83, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(110, 84, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(267, 218, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(268, 219, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(269, 220, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(270, 221, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(271, 222, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(272, 223, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(273, 224, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(274, 225, 'Básico', NULL, NULL, '', 0, 1, NULL, NULL, NULL),
(275, 225, 'Medio', NULL, NULL, '', 0, 2, NULL, NULL, NULL),
(276, 225, 'Alto', NULL, NULL, '', 0, 3, NULL, NULL, NULL),
(277, 226, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(278, 227, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(279, 228, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(280, 229, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(281, 230, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(282, 231, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(283, 232, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(284, 233, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(285, 234, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(286, 235, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(287, 236, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(288, 237, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(289, 238, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(290, 239, 'Acceso', NULL, NULL, '', 0, 1, NULL, NULL, NULL),
(291, 239, 'Rectificación', NULL, NULL, '', 0, 2, NULL, NULL, NULL),
(292, 239, 'Cancelación', NULL, NULL, '', 0, 3, NULL, NULL, NULL),
(293, 239, 'Oposición', NULL, NULL, '', 0, 4, NULL, NULL, NULL),
(294, 240, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(295, 241, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(296, 242, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(297, 243, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(298, 244, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(299, 245, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(300, 246, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(301, 247, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(302, 248, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(303, 249, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(304, 250, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(305, 251, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(306, 252, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(307, 253, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(308, 254, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0),
(309, 255, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(310, 256, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(311, 257, 'C - Media', NULL, NULL, '##background-color: #c4ecc2##', 0, 1, NULL, 1, 0),
(312, 257, 'B - Alta', NULL, NULL, '##background-color: #ffeac1##', 0, 2, NULL, 0, 0),
(313, 257, 'A - Muy Alta', NULL, NULL, '##background-color: #e9b1c3##', 0, 3, NULL, 0, 0),
(314, 258, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(315, 259, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(316, 260, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(317, 261, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mensaje`
--

DROP TABLE IF EXISTS `mensaje`;
CREATE TABLE IF NOT EXISTS `mensaje` (
  `id_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `asunto` varchar(255) DEFAULT NULL,
  `cuerpo` text,
  `fecha` datetime DEFAULT NULL,
  `email` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_mensaje`),
  KEY `FI_usuario_mensaje` (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Table structure for table `mensaje_destino`
--

DROP TABLE IF EXISTS `mensaje_destino`;
CREATE TABLE IF NOT EXISTS `mensaje_destino` (
  `id_mensaje` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `leido` tinyint(4) DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_mensaje`,`id_usuario`),
  KEY `FI_usuario_mensaje_destino` (`id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mensaje_destino`
--


-- --------------------------------------------------------

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
CREATE TABLE IF NOT EXISTS `notificaciones` (
  `notid` int(11) NOT NULL AUTO_INCREMENT,
  `soporte` enum('Formulario en papel','Internet','Internet firmado con certificado digital') COLLATE utf8_unicode_ci NOT NULL,
  `tipo` enum('Inscripcion','Modificacion','Supresion') COLLATE utf8_unicode_ci NOT NULL,
  `tipo_noti` tinyint(1) DEFAULT NULL,
  `id_fichero` int(11) NOT NULL,
  `fecha` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `hora_proceso` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `procesado` int(4) DEFAULT '0',
  `hay_que_parar` tinyint(4) DEFAULT '0',
  `modelo` enum('Normal','Tipo') COLLATE utf8_unicode_ci NOT NULL,
  `titularidad` enum('1','2') COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` enum('5','6') COLLATE utf8_unicode_ci NOT NULL,
  `forma` enum('u','v','w','x','y','z','0') COLLATE utf8_unicode_ci NOT NULL,
  `id_upload` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `pf_razon_s` varchar(140) COLLATE utf8_unicode_ci NOT NULL,
  `pf_cif_nif` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `pf_nombre` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `pf_apellido1` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `pf_apellido2` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `pf_nif` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pf_cargo` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `dec_razon_s` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `dec_direccion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dec_localidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dec_cp` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dec_provincia` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dec_pais` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `dec_tel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dec_fax` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dec_mail` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dec_forma` tinyint(1) NOT NULL,
  `rf_nombre` varchar(140) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_actividad` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_cif` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `rf_domicilio` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `rf_localidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `rf_cp` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_provincia` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_pais` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `rf_tel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_fax` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rf_mail` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_nombreof` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_cif` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_dirpostal` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_localidad` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_cp` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_provincia` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `dr_pais` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_tel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_fax` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dr_mail` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_solicitud` tinyint(1) NOT NULL,
  `ac_mod_responsable` tinyint(1) DEFAULT NULL,
  `ac_mod_cif_nif_ant` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ac_mod_servicio_unidad` tinyint(1) DEFAULT NULL,
  `ac_mod_disposicion` tinyint(1) DEFAULT NULL,
  `ac_mod_iden_finalid` tinyint(1) DEFAULT NULL,
  `ac_mod_encargado` tinyint(1) DEFAULT NULL,
  `ac_mod_estruct_sistema` tinyint(1) DEFAULT NULL,
  `ac_mod_medidas_seg` tinyint(1) DEFAULT NULL,
  `ac_mod_origen` tinyint(1) DEFAULT NULL,
  `ac_mod_trans_inter` tinyint(1) DEFAULT NULL,
  `ac_mod_comunic_ces` tinyint(1) DEFAULT NULL,
  `ac_supr_motivos` varchar(140) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ac_supr_destino_previsiones` varchar(210) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ac_supr_cifnif` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_nombre` varchar(140) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_cif` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_dirpostal` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_localidad` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_cp` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_provincia` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_pais` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_tel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_fax` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `et_mail` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idn_nombre` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idn_descripcion` text COLLATE utf8_unicode_ci,
  `idn_finalidades` varchar(23) COLLATE utf8_unicode_ci DEFAULT NULL,
  `indica_inte` tinyint(1) DEFAULT NULL,
  `indica_otras` tinyint(1) DEFAULT NULL,
  `indic_fap` tinyint(1) DEFAULT NULL,
  `indic_rp` tinyint(1) DEFAULT NULL,
  `indic_ep` tinyint(1) DEFAULT NULL,
  `indic_ap` tinyint(1) DEFAULT NULL,
  `op_colectivos` varchar(17) COLLATE utf8_unicode_ci DEFAULT NULL,
  `op_otroscol` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ind_ide` tinyint(1) DEFAULT NULL,
  `ind_as` tinyint(1) DEFAULT NULL,
  `ind_r` tinyint(1) DEFAULT NULL,
  `ind_c` tinyint(1) DEFAULT NULL,
  `ind_re` tinyint(1) DEFAULT NULL,
  `ind_sal` tinyint(1) DEFAULT NULL,
  `ind_sexo` tinyint(1) DEFAULT NULL,
  `ind_nif` tinyint(1) DEFAULT NULL,
  `ind_ss` tinyint(1) DEFAULT NULL,
  `ind_n_a` tinyint(1) DEFAULT NULL,
  `ind_ts` tinyint(1) DEFAULT NULL,
  `ind_dir` tinyint(1) DEFAULT NULL,
  `ind_tel` tinyint(1) DEFAULT NULL,
  `ind_huella` tinyint(1) DEFAULT NULL,
  `ind_img` tinyint(1) DEFAULT NULL,
  `ind_marcas` tinyint(1) DEFAULT NULL,
  `ind_firma` tinyint(1) DEFAULT NULL,
  `td_otrosprotegidos` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `td_otrostipificados` varchar(17) COLLATE utf8_unicode_ci DEFAULT NULL,
  `td_otrostiposdatos` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `td_tratamiento` enum('1','2','3') COLLATE utf8_unicode_ci DEFAULT NULL,
  `seguridad` enum('1','2','3') COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_destinatarios` varchar(17) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_otrosdestinatarios` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paises_destina` varchar(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cat_destina` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otro_pais_destina` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`notid`),
  KEY `FI_fichero` (`id_fichero`),
  FULLTEXT KEY `fecha_proceso` (`fecha`),
  FULLTEXT KEY `fecha_proceso_2` (`fecha`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=378 ;

--
-- Dumping data for table `notificaciones`
--


-- --------------------------------------------------------

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
CREATE TABLE IF NOT EXISTS `paises` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pais` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cod` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=201 ;

--
-- Dumping data for table `paises`
--

INSERT INTO `paises` (`pid`, `pais`, `cod`) VALUES
(1, 'AFGANISTAN', 'AF'),
(2, 'ALBANIA', 'AL'),
(3, 'ALEMANIA', 'DE'),
(4, 'ANDORRA', 'AD'),
(5, 'ANGOLA', 'AO'),
(6, 'ANTIGUA Y BARBUDA', 'AG'),
(7, 'ARABIA SAUDI', 'SA'),
(8, 'ARGELIA', 'DZ'),
(9, 'ARGENTINA', 'AR'),
(10, 'ARMENIA', 'AM'),
(11, 'AUSTRALIA', 'AU'),
(12, 'AUSTRIA', 'AT'),
(13, 'AZERBAIYAN', 'AZ'),
(14, 'BAHAMAS', 'BS'),
(15, 'BAHREIN', 'BH'),
(16, 'BANGLADESH', 'BD'),
(17, 'BARBADOS', 'BB'),
(18, 'BIELORRUSIA', 'BY'),
(19, 'BELGICA', 'BE'),
(20, 'BELICE', 'BZ'),
(21, 'BENIN', 'BJ'),
(22, 'BHUTAN', 'BT'),
(23, 'BOLIVIA', 'BO'),
(24, 'BOSNIA HERZEGOVINA', 'BA'),
(25, 'BOSTWANA', 'BW'),
(26, 'BRASIL', 'BR'),
(27, 'BRUNEI DARUSSALAM', 'BN'),
(28, 'BULGARIA', 'BG'),
(29, 'BURKINA FASO', 'BF'),
(30, 'BURUNDI', 'BI'),
(31, 'CABO VERDE', 'CV'),
(32, 'CAMBOYA', 'KH'),
(33, 'CAMERUN', 'CM'),
(34, 'CANADA', 'CA'),
(35, 'CHAD', 'TD'),
(36, 'CHILE', 'CL'),
(37, 'CHINA', 'CN'),
(38, 'CHIPRE', 'CY'),
(39, 'COLOMBIA', 'CO'),
(40, 'COMORAS', 'KM'),
(41, 'CONGO', 'CG'),
(42, 'COSTA DE MARFIL', 'CI'),
(43, 'COSTA RICA', 'CR'),
(44, 'CROACIA', 'HR'),
(45, 'CUBA', 'CU'),
(46, 'DINAMARCA', 'DK'),
(47, 'DJIBOUTI', 'DJ'),
(48, 'DOMINICA', 'DM'),
(49, 'ECUADOR', 'EC'),
(50, 'EGIPTO', 'EG'),
(51, 'EL SALVADOR', 'SV'),
(52, 'EMIRATOS ARABES', 'AE'),
(53, 'ERITREA', 'ER'),
(54, 'ESLOVENIA', 'SI'),
(55, 'ESPAÑA', 'ES'),
(56, 'ESTADOS UNIDOS', 'US'),
(57, 'ESTONIA', 'EE'),
(58, 'ETIOPIA', 'ET'),
(59, 'FEDERACION DE RUSIA', 'RU'),
(60, 'FIJI', 'FJ'),
(61, 'FILIPINAS', 'PH'),
(62, 'FINLANDIA', 'FI'),
(63, 'FRANCIA', 'FR'),
(64, 'GABON', 'GA'),
(65, 'GAMBIA', 'GM'),
(66, 'GEORGIA', 'GE'),
(67, 'GHANA', 'GH'),
(68, 'GRANADA', 'GD'),
(69, 'GRECIA', 'GR'),
(70, 'GROENLANDIA', 'GL'),
(71, 'GUATEMALA', 'GT'),
(72, 'GUERNSEY', 'GG'),
(73, 'GUINEA', 'GN'),
(74, 'GUINEA BISSAU', 'GW'),
(75, 'GUINEA ECUATORIAL', 'GQ'),
(76, 'GUYANA', 'GY'),
(77, 'HAITI', 'HT'),
(78, 'HONDURAS', 'HN'),
(79, 'HONG KONG', 'HK'),
(80, 'HUNGRIA', 'HU'),
(81, 'INDIA', 'IN'),
(82, 'INDONESIA', 'ID'),
(83, 'IRAN', 'IR'),
(84, 'IRAQ', 'IQ'),
(85, 'IRLANDA', 'IE'),
(86, 'ISLA DE MAN', 'IM'),
(87, 'ISLANDIA', 'IS'),
(88, 'ISLAS FEROE', 'FO'),
(89, 'ISLAS MARSHALL', 'MH'),
(90, 'ISLAS SALOMON', 'SB'),
(91, 'ISRAEL', 'IL'),
(92, 'ITALIA', 'IT'),
(93, 'JAMAICA', 'JM'),
(94, 'JAPON', 'JP'),
(95, 'JORDANIA', 'JO'),
(96, 'KAZAJSTAN', 'KZ'),
(97, 'KENIA', 'KE'),
(98, 'KIRGUISTAN', 'KG'),
(99, 'KIRIBATI', 'KI'),
(100, 'KUWAIT', 'KW'),
(101, 'LESOTHO', 'LS'),
(102, 'LETONIA', 'LV'),
(103, 'LIBANO', 'LB'),
(104, 'LIBERIA', 'LR'),
(105, 'LIBIA', 'LY'),
(106, 'LIECHTENSTEIN', 'LI'),
(107, 'LITUANIA', 'LT'),
(108, 'LUXEMBURGO', 'LU'),
(109, 'MACEDONIA', 'MK'),
(110, 'MADAGASCAR', 'MG'),
(111, 'MALASIA', 'MY'),
(112, 'MALAWI', 'MW'),
(113, 'MALDIVAS', 'MV'),
(114, 'MALI', 'ML'),
(115, 'MALTA', 'MT'),
(116, 'MARRUECOS', 'MA'),
(117, 'MAURICIO', 'MU'),
(118, 'MAURITANIA', 'MR'),
(119, 'MEJICO', 'MX'),
(120, 'MICRONESIA', 'FM'),
(121, 'MONACO', 'MC'),
(122, 'MONGOLIA', 'MN'),
(123, 'MONTENEGRO', 'ME'),
(124, 'MOZAMBIQUE', 'MZ'),
(125, 'MYANMAR', 'MM'),
(126, 'MAIMIBIA', 'NA'),
(127, 'NAURU', 'NR'),
(128, 'NEPAL', 'NP'),
(129, 'NICARAGUA', 'NI'),
(130, 'NIGER', 'NE'),
(131, 'NIGERIA', 'NG'),
(132, 'NORUEGA', 'NO'),
(133, 'NUEVA ZELANDA', 'NZ'),
(134, 'OMAN', 'OM'),
(136, 'PAISES BAJOS', 'NL'),
(137, 'PALAU', 'PW'),
(138, 'PANAMA', 'PA'),
(139, 'PAPUA NUEVA GUINEA', 'PG'),
(140, 'PAQUISTAN', 'PK'),
(141, 'PARAGUAY', 'PY'),
(142, 'PERU', 'PE'),
(143, 'POLONIA', 'PL'),
(144, 'PORTUGAL', 'PT'),
(145, 'PUERTO RICO', 'PR'),
(146, 'QATAR', 'QA'),
(147, 'REINO UNIDO', 'GB'),
(148, 'REPUBLICA CENTROAFRICANA', 'CF'),
(149, 'REPUBLICA CHECA', 'CZ'),
(150, 'REPUBLICA DE COREA', 'KR'),
(151, 'REPUBLICA DOMINICANA', 'DO'),
(152, 'REPUBLICA DE MOLDOVA', 'MD'),
(153, 'REP.DEM.DEL CONGO', 'CD'),
(154, 'REP.DEM.POP.DE COREA', 'KP'),
(155, 'REP.DEM.POP.DE LAOS', 'LA'),
(156, 'REP.DEM. DE TIMOR-LESTE', 'TL'),
(157, 'REPUBLICA ESLOVACA', 'SK'),
(158, 'RUMANIA', 'RO'),
(159, 'RWANDA', 'RW'),
(160, 'SAINT KITTS Y NEVIS', 'KN'),
(161, 'SAMOA', 'WS'),
(162, 'SAN MARINO', 'SM'),
(163, 'S.VICENTE Y GRANADINAS', 'VC'),
(164, 'SANTA LUCIA', 'LC'),
(165, 'SANTO TOME Y PRINCIPE', 'ST'),
(166, 'SENEGAL', 'SN'),
(167, 'SERBIA', 'RS'),
(168, 'SEYCHELLES', 'SC'),
(169, 'SIERRA LEONA', 'SL'),
(170, 'SINGAPUR', 'SG'),
(171, 'SIRIA', 'SY'),
(172, 'SOMALIA', 'SO'),
(173, 'SRI LANKA', 'LK'),
(174, 'SUDAFRICA', 'ZA'),
(175, 'SUDAN', 'SD'),
(176, 'SUECIA', 'SE'),
(177, 'SUIZA', 'CH'),
(178, 'SURINAM', 'SR'),
(179, 'SWAZILANDA', 'SZ'),
(180, 'TAILANDIA', 'TH'),
(181, 'TAIWAN', 'TW'),
(182, 'TANZANIA', 'TZ'),
(183, 'TAYIKISTAN', 'TJ'),
(184, 'TOGO', 'TG'),
(185, 'TONGA', 'TO'),
(186, 'TRINIDAD Y TOBAGO', 'TT'),
(187, 'TUNEZ', 'TN'),
(188, 'TURKMENISTAN', 'TM'),
(189, 'TURQUIA', 'TR'),
(190, 'TUVALU', 'TV'),
(191, 'UCRANIA', 'UA'),
(192, 'UGANDA', 'UG'),
(193, 'URUGUAY', 'UY'),
(194, 'UZBEKISTAN', 'UZ'),
(195, 'VANUATU', 'VU'),
(196, 'VENEZUELA', 'VE'),
(197, 'VIETNAM', 'VN'),
(198, 'YEMEN', 'YE'),
(199, 'ZAMBIA', 'ZM'),
(200, 'ZIMBABWE', 'ZW');

-- --------------------------------------------------------

--
-- Table structure for table `parametro`
--

DROP TABLE IF EXISTS `parametro`;
CREATE TABLE IF NOT EXISTS `parametro` (
  `id_parametro` int(11) NOT NULL AUTO_INCREMENT,
  `tipoParametro` varchar(100) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `numero` float DEFAULT NULL,
  `numero2` float DEFAULT NULL,
  `cadena` text,
  `cadena1` text,
  `otroObjeto` int(11) DEFAULT NULL,
  `si_no` tinyint(4) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `fechaBorrado` datetime DEFAULT NULL,
  `nombreFichero` varchar(200) DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `fichero` text,
  `tamano` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_parametro`),
  KEY `FI_parametro_definicion_parametro` (`tipoParametro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `parametro`
--

INSERT INTO `parametro` (`id_parametro`, `tipoParametro`, `nombre`, `orden`, `numero`, `numero2`, `cadena`, `cadena1`, `otroObjeto`, `si_no`, `fecha`, `created_at`, `updated_at`, `fechaBorrado`, `nombreFichero`, `tipo`, `fichero`, `tamano`) VALUES
(56, '_TIPO_UNIDAD_', '€', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2009-05-28 17:56:36', '2009-05-28 17:56:36', NULL, NULL, NULL, NULL, NULL),
(55, '_TIPO_UNIDAD_', 'm2', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2009-05-28 17:56:17', '2009-05-28 17:56:17', NULL, NULL, NULL, NULL, NULL),
(59, '_CATEGORIA_TABLA_', 'MÓDULOS', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-07-19 13:45:01', '2010-10-27 14:04:28', NULL, NULL, NULL, NULL, NULL),
(58, '_CATEGORIA_TABLA_', 'LOPD GENERAL', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-06-23 14:29:45', '2010-06-24 15:38:20', NULL, NULL, NULL, NULL, NULL),
(57, '_COMUNICACION_APD_', 'en pruebas?', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2009-10-23 16:03:03', NULL, NULL, NULL, NULL, NULL),
(60, '_ESTADO_TAREA_', 'Planeado', 1, 1, NULL, NULL, NULL, NULL, 0, NULL, '2010-08-17 13:39:22', '2010-08-17 13:39:22', NULL, NULL, NULL, NULL, NULL),
(61, '_ESTADO_TAREA_', 'No Iniciado', 2, 2, NULL, NULL, NULL, NULL, 0, NULL, '2010-08-17 13:39:33', '2010-08-17 13:39:33', NULL, NULL, NULL, NULL, NULL),
(62, '_ESTADO_TAREA_', 'En Progreso', 3, 3, NULL, NULL, NULL, NULL, 0, NULL, '2010-08-17 13:39:56', '2010-08-17 13:39:56', NULL, NULL, NULL, NULL, NULL),
(63, '_ESTADO_TAREA_', 'Completado', 4, 4, NULL, NULL, NULL, NULL, 0, NULL, '2010-08-17 13:40:07', '2010-08-17 13:40:07', NULL, NULL, NULL, NULL, NULL),
(64, '_ESTADO_TAREA_', 'Planeado', 5, 5, NULL, NULL, NULL, NULL, 1, NULL, '2010-08-17 13:40:17', '2010-08-17 13:40:17', NULL, NULL, NULL, NULL, NULL),
(65, '_ESTADO_TAREA_', 'Pendiente', 6, 6, NULL, NULL, NULL, NULL, 1, NULL, '2010-08-17 13:40:31', '2010-08-17 13:40:31', NULL, NULL, NULL, NULL, NULL),
(66, '_ESTADO_TAREA_', 'Realizado', 7, 7, NULL, NULL, NULL, NULL, 1, NULL, '2010-08-17 13:40:42', '2010-08-17 13:40:42', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `parametro_def`
--

DROP TABLE IF EXISTS `parametro_def`;
CREATE TABLE IF NOT EXISTS `parametro_def` (
  `tipoParametro` varchar(100) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` text,
  `esLista` tinyint(4) DEFAULT NULL,
  `camposLista` text,
  `campoNombre` varchar(150) DEFAULT NULL,
  `campoNumero` varchar(150) DEFAULT NULL,
  `campoNumero2` varchar(150) DEFAULT NULL,
  `campoCadena` text,
  `campoCadena1` varchar(150) DEFAULT NULL,
  `campoCadenaMultiIdioma` varchar(150) DEFAULT NULL,
  `campoOtroObjeto` text,
  `campoSiNo` varchar(150) DEFAULT NULL,
  `campoFecha` varchar(150) DEFAULT NULL,
  `campoFichero` varchar(150) DEFAULT NULL,
  `esEditable` tinyint(4) DEFAULT '1',
  `esBorrable` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`tipoParametro`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parametro_def`
--

INSERT INTO `parametro_def` (`tipoParametro`, `nombre`, `descripcion`, `esLista`, `camposLista`, `campoNombre`, `campoNumero`, `campoNumero2`, `campoCadena`, `campoCadena1`, `campoCadenaMultiIdioma`, `campoOtroObjeto`, `campoSiNo`, `campoFecha`, `campoFichero`, `esEditable`, `esBorrable`) VALUES
('_TIPO_UNIDAD_', 'Tipo Unidad', NULL, 1, '$this->getNombre()', 'Nombre', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
('_COMUNICACION_APD_', 'Envio de ficheros a la APD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'En Pruebas?', NULL, NULL, 1, 1),
('_CATEGORIA_TABLA_', 'Categoría de las Tablas', NULL, 1, '$this->getNombre()', 'Nombre', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
('_ESTADO_TAREA_', 'Estado de tareas/eventos', NULL, 1, '$this->getNombre()', 'Nombre', 'Orden', NULL, NULL, NULL, NULL, NULL, 'Es de evento?', NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
CREATE TABLE IF NOT EXISTS `provincia` (
  `id_provincia` int(11) NOT NULL AUTO_INCREMENT,
  `pais` varchar(2) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_provincia`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `provincia`
--

INSERT INTO `provincia` (`id_provincia`, `pais`, `nombre`) VALUES
(1, 'ES', 'Alava'),
(2, 'ES', 'Albacete'),
(3, 'ES', 'Alicante'),
(4, 'ES', 'Almeria'),
(5, 'ES', 'Asturias'),
(6, 'ES', 'Avila'),
(7, 'ES', 'Badajoz'),
(8, 'ES', 'Barcelona'),
(9, 'ES', 'Burgos'),
(10, 'ES', 'Caceres'),
(11, 'ES', 'Cadiz'),
(12, 'ES', 'Cantabria'),
(13, 'ES', 'Castellon'),
(14, 'ES', 'Ciudad Real'),
(15, 'ES', 'Cordoba'),
(16, 'ES', 'La Coruña'),
(17, 'ES', 'Cuenca'),
(18, 'ES', 'Gerona'),
(19, 'ES', 'Granada'),
(20, 'ES', 'Guadalajara'),
(21, 'ES', 'Guipucoa'),
(22, 'ES', 'Huelva'),
(23, 'ES', 'Huesca'),
(24, 'ES', 'Islas Baleares'),
(25, 'ES', 'Jaen'),
(26, 'ES', 'Leon'),
(27, 'ES', 'Lerida'),
(28, 'ES', 'Lugo'),
(29, 'ES', 'Madrid'),
(30, 'ES', 'Malaga'),
(31, 'ES', 'Murcia'),
(32, 'ES', 'Navarra'),
(33, 'ES', 'Orense'),
(34, 'ES', 'Palencia'),
(35, 'ES', 'Las Palmas'),
(36, 'ES', 'Pontevedra'),
(37, 'ES', 'La Rioja'),
(38, 'ES', 'Salamanca'),
(39, 'ES', 'Santa Cruz de Tenerife'),
(40, 'ES', 'Segovia'),
(41, 'ES', 'Sevilla'),
(42, 'ES', 'Soria'),
(43, 'ES', 'Tarragona'),
(44, 'ES', 'Teruel'),
(45, 'ES', 'Toledo'),
(46, 'ES', 'Valencia'),
(47, 'ES', 'Valladolid'),
(48, 'ES', 'Vizcaya'),
(49, 'ES', 'Zamora'),
(50, 'ES', 'Zaragoza'),
(51, 'ES', 'Ceuta'),
(52, 'ES', 'Melilla');

-- --------------------------------------------------------

--
-- Table structure for table `rel_campo_tabla`
--

DROP TABLE IF EXISTS `rel_campo_tabla`;
CREATE TABLE IF NOT EXISTS `rel_campo_tabla` (
  `id_campo` int(11) NOT NULL,
  `id_tabla` int(11) NOT NULL,
  PRIMARY KEY (`id_campo`,`id_tabla`),
  KEY `FI_tabla_rel_campo_tabla` (`id_tabla`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rel_campo_tabla`
--

INSERT INTO `rel_campo_tabla` (`id_campo`, `id_tabla`) VALUES
(33, 4),
(34, 5),
(35, 5),
(36, 5),
(37, 5),
(38, 6),
(39, 6),
(40, 6),
(41, 6),
(42, 6),
(43, 9),
(44, 10),
(45, 10),
(46, 10),
(47, 7),
(48, 7),
(49, 7),
(50, 7),
(51, 8),
(52, 8),
(53, 8),
(54, 8),
(56, 8),
(57, 8),
(62, 16),
(64, 17),
(65, 17),
(66, 17),
(67, 17),
(68, 17),
(69, 17),
(70, 5),
(71, 10),
(72, 10),
(73, 10),
(74, 9),
(75, 18),
(77, 18),
(78, 19),
(79, 19),
(80, 19),
(81, 20),
(82, 20),
(83, 20),
(84, 20),
(174, 44),
(175, 44),
(176, 44),
(177, 44),
(178, 44),
(179, 45),
(180, 46),
(181, 46),
(182, 46),
(183, 46),
(184, 46),
(185, 47),
(186, 47),
(187, 47),
(188, 47),
(189, 48),
(190, 48),
(191, 48),
(192, 48),
(193, 48),
(194, 48),
(195, 49),
(196, 49),
(197, 50),
(198, 50),
(199, 50),
(200, 50),
(201, 50),
(202, 50),
(203, 51),
(204, 51),
(205, 51),
(206, 51),
(207, 51),
(208, 51),
(209, 52),
(210, 52),
(211, 53),
(212, 53),
(213, 53),
(214, 54),
(215, 54),
(216, 54),
(217, 54),
(218, 8),
(219, 57),
(220, 57),
(221, 57),
(222, 57),
(223, 55),
(224, 55),
(225, 55),
(226, 55),
(227, 56),
(228, 56),
(229, 56),
(230, 56),
(231, 56),
(232, 58),
(233, 58),
(234, 58),
(235, 58),
(236, 58),
(237, 58),
(238, 59),
(239, 59),
(240, 59),
(241, 59),
(242, 59),
(243, 59),
(244, 60),
(245, 60),
(246, 60),
(247, 60),
(248, 62),
(249, 62),
(250, 62),
(251, 62),
(252, 62),
(253, 62),
(254, 62),
(255, 55),
(256, 63),
(257, 63),
(258, 63),
(259, 63),
(260, 63),
(261, 63);

-- --------------------------------------------------------

--
-- Table structure for table `sesion`
--

DROP TABLE IF EXISTS `sesion`;
CREATE TABLE IF NOT EXISTS `sesion` (
  `id_sesion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(15) NOT NULL,
  `sesion` varchar(50) DEFAULT NULL,
  `IP` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_sesion`),
  KEY `FI_itasDeUsuarios` (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=180 ;

--
-- Dumping data for table `sesion`
--


-- --------------------------------------------------------

--
-- Table structure for table `sesion_log`
--

DROP TABLE IF EXISTS `sesion_log`;
CREATE TABLE IF NOT EXISTS `sesion_log` (
  `id_log` int(15) NOT NULL AUTO_INCREMENT,
  `id_sesion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `URL` varchar(100) NOT NULL,
  `modulo` varchar(40) DEFAULT NULL,
  `accion` varchar(40) DEFAULT NULL,
  `firma` text,
  `public_key` text,
  `parametros` text NOT NULL,
  `mensaje` text NOT NULL,
  PRIMARY KEY (`id_log`),
  KEY `FI_inasVistas` (`id_sesion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6532 ;

--
-- Dumping data for table `sesion_log`
--



-- --------------------------------------------------------

--
-- Table structure for table `tabla`
--

DROP TABLE IF EXISTS `tabla`;
CREATE TABLE IF NOT EXISTS `tabla` (
  `id_tabla` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `mostrar_en_lista` tinyint(4) NOT NULL,
  `orden` int(11) DEFAULT NULL,
  `es_ficheros` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `borrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_tabla`),
  KEY `FI_tabla_empresa` (`id_empresa`),
  KEY `FI_usuario_tabla` (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `tabla`
--

INSERT INTO `tabla` (`id_tabla`, `id_usuario`, `id_empresa`, `nombre`, `imagen`, `mostrar_en_lista`, `orden`, `es_ficheros`, `id_categoria`, `created_at`, `updated_at`, `borrado`) VALUES
(5, 2, 10, 'Ficheros', NULL, 1, 8, 1, 58, '2009-05-22 09:03:42', '2010-10-27 18:12:38', NULL),
(4, 2, 10, 'Departamentos', NULL, 0, 17, 0, 58, '2009-05-22 09:03:30', '2010-07-19 14:33:18', NULL),
(6, 2, 10, 'Gestion Ficheros', NULL, 1, 9, 0, 58, '2009-05-22 09:03:50', '2010-10-27 18:12:38', NULL),
(7, 2, 10, 'Gestion Recursos', NULL, 1, 11, 0, 58, '2009-05-22 09:04:06', '2010-09-09 11:09:32', NULL),
(8, 2, 10, 'Incidencias', NULL, 1, 18, 0, 58, '2009-05-22 09:04:16', '2010-07-19 14:33:18', NULL),
(9, 2, 10, 'Recursos Protegidos', NULL, 1, 10, 0, 58, '2009-05-22 09:04:26', '2010-07-19 14:33:18', NULL),
(10, 2, 10, 'Soportes Informaticos', NULL, 1, 13, 0, 58, '2009-05-22 09:04:35', '2010-09-09 11:09:43', NULL),
(55, 2, 10, 'Auditorias Realizadas', NULL, 1, 0, NULL, 59, '2010-07-19 14:13:08', '2010-09-09 11:10:26', NULL),
(17, 2, 10, 'Acciones sobre Incidencias', NULL, 0, 12, 0, 58, '2009-06-12 13:55:48', '2010-07-19 14:33:18', NULL),
(18, 2, 10, 'Formación LOPD personal', NULL, 1, 16, 0, 58, '2009-10-06 12:17:36', '2010-07-19 14:33:18', NULL),
(19, 2, 10, 'Autorizaciones Backup', NULL, 1, 15, 0, 58, '2009-10-06 12:36:10', '2010-07-19 14:33:18', NULL),
(20, 2, 10, 'Gestion Copias Seguridad', NULL, 1, 14, 0, 58, '2009-10-06 12:39:19', '2010-09-09 11:09:57', NULL),
(56, 2, 10, 'Subcontrataciones', NULL, 0, 2, NULL, 59, '2010-07-19 14:13:40', '2010-10-27 18:12:38', NULL),
(57, 2, 10, 'Servicios', NULL, 1, 3, NULL, 59, '2010-07-19 14:13:54', '2010-10-27 18:12:38', NULL),
(58, 2, 10, 'Conservacion Informacion', NULL, 0, 4, NULL, 59, '2010-07-19 14:14:11', '2010-10-27 18:12:38', NULL),
(59, 2, 10, 'Gestion Derechos', NULL, 1, 5, NULL, 59, '2010-07-19 14:14:25', '2010-10-27 18:12:38', NULL),
(60, 2, 10, 'Gestion Medidas Seguridad', NULL, 0, 6, NULL, 59, '2010-07-19 14:16:00', '2010-10-27 18:12:38', NULL),
(61, 2, 10, 'Elaboración Contratos', NULL, 1, 6, NULL, 59, '2010-07-19 14:16:48', '2010-07-20 14:23:42', 1),
(62, 2, 10, 'Gestion Firma', NULL, 0, 7, NULL, 59, '2010-07-19 14:17:10', '2010-10-27 17:40:23', NULL),
(63, 2, 10, 'Recomendaciones de las auditorias', NULL, 1, 1, NULL, 59, '2010-10-27 18:12:29', '2010-10-27 18:12:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tarea`
--

DROP TABLE IF EXISTS `tarea`;
CREATE TABLE IF NOT EXISTS `tarea` (
  `id_tarea` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_estado_tarea` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `avisar_email` tinyint(4) DEFAULT NULL,
  `avisar_email_fin` tinyint(4) DEFAULT NULL,
  `es_evento` tinyint(4) DEFAULT NULL,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_vencimiento` datetime DEFAULT NULL,
  `resumen` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `id_campo` int(11) DEFAULT NULL,
  `id_formulario` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_tarea`),
  KEY `FI_tarea_usuario` (`id_usuario`),
  KEY `FI_tarea_parametro` (`id_estado_tarea`),
  KEY `FI_tarea_empresa` (`id_empresa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=106 ;

--
-- Dumping data for table `tarea`
--

-- --------------------------------------------------------

--
-- Table structure for table `taula1`
--

DROP TABLE IF EXISTS `taula1`;
CREATE TABLE IF NOT EXISTS `taula1` (
  `t1id` varchar(3) NOT NULL,
  `actividad` text,
  PRIMARY KEY (`t1id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula1`
--

INSERT INTO `taula1` (`t1id`, `actividad`) VALUES
('N01', 'COMERCIO'),
('N02', 'SANIDAD'),
('N03', 'CONTABILIDAD, AUDITORIA Y ASESORIA FISCAL'),
('N04', 'ASOCIACIONES Y CLUBES'),
('N05', 'ACTIVIDADES INMOBILIARIAS'),
('N06', 'INDUSTRIA QUIMICA Y FARMACEUTICA'),
('N07', 'CONTRUCCION'),
('N08', 'TURISMO Y HOSTELERIA'),
('N09', 'MAQUINARIA Y MEDIOS DE TRANSPORTE'),
('N10', 'EDUCACION'),
('N11', 'TRANSPORTE'),
('N12', 'SEGUROS PRIVADOS'),
('N13', 'SERVICIOS INFORMATICOS'),
('N14', 'ACTIVIDADES RELACIONADAS CON LOS PRODUCTOS ALIMENTICIOS, BEBIDAS Y TABACOS'),
('N15', 'AGRICULTURA, GANADERIA, EXPLOTACION FORESTAL, CAZA, PESCA'),
('N16', 'ENTIDADES BANCARIAS Y FINANCIERAS'),
('N17', 'PRODUCCION DE BIENES DE CONSUMO'),
('N18', 'SECTOR ENERGETICO'),
('N19', 'ACTIVIDADES JURIDICAS, NOTARIOS Y REGISTRADORES'),
('N20', 'ACTIVIDADES DIVERSAS DE SERVICIOS PERSONALES'),
('N21', 'ACTIVIDADES DE ORGANIZACIONES EMPRESARIALES, PROFESIONALES Y PATRONALES'),
('N22', 'ACTIVIDADES DE SERVICIOS SOCIALES'),
('N23', 'PUBLICIDAD DIRECTA'),
('N24', 'SERVICIOS DE TELECOMUNICACIONES'),
('N25', 'ACTIVIDADES RELACIONADAS CON LOS JUEGOS DE AZAR Y APUESTAS'),
('N26', 'SEGURIDAD'),
('N27', 'SELECCION DE PERSONAL'),
('N28', 'ACTIVIDADES POSTALES Y DE CORREO(OPERADORES POSTALES, EMPRESAS PRESTADORAS DE SERVICIOS POSTALES, TRANSPORTISTAS...)'),
('N29', 'INVESTIGACION Y DESARROLLO (I+D)'),
('N30', 'ACTIVIDADES POLITICAS, SINDICALES Y RELIGIOSAS'),
('N31', 'MUTUALIDADES COLABORADORAS DE LOS ORGANISMOS DE LA SEGURIDAD SOCIAL'),
('N32', 'ORGANIZACION DE FERIAS, EXHIBICIONES, CONGRESOS, Y OTRAS ACTIVIDADES RELACIONADAS'),
('N33', 'SOLVENCIA PATRIMONIAL Y CREDITO'),
('N34', 'INSPECCION TECNICA DE VEHICULOS Y OTROS ANALISIS TECNICOS'),
('N35', 'COMERCIO Y SERVICIOS ELECTRONICOS'),
('N36', 'COMUNIDADES DE PROPIETARIOS'),
('N99', 'OTRAS ACTIVIDADES');

-- --------------------------------------------------------

--
-- Table structure for table `taula2`
--

DROP TABLE IF EXISTS `taula2`;
CREATE TABLE IF NOT EXISTS `taula2` (
  `t2id` int(11) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`t2id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula2`
--

INSERT INTO `taula2` (`t2id`, `descripcion`) VALUES
(400, 'GESTION DE CLIENTES, CONTABLE, FISCAL Y ADMINISTRATIVA'),
(401, 'RECURSOS HUMANOS'),
(402, 'GESTION DE NOMINAS'),
(403, 'PREVENCION DE RIESGOS LABORALES'),
(404, 'PRESTACION DE SERVICIOS DE SOLVENCIA PATRIMONIAL Y CREDITO'),
(405, 'CUMPLIMENTO/INCUMPLIMENTO DE OBLIGACIONES DINERARIAS'),
(406, 'SERVICIOS ECONOMICOS-FINANCIEROS Y SEGUROS'),
(407, 'ANALISIS DE PERFILES'),
(408, 'PUBLICIDAD Y PROSPECCION COMERCIAL'),
(409, 'PRESTACION DE SERVICIOS DE COMUNICACIONES ELECTRONICAS'),
(410, 'GUIAS/REPERTORIOS DE SERVICIOS DE COMUNICACIONES ELECTRONICAS'),
(411, 'COMERCIO ELECTRONICO'),
(412, 'PRESTACION DE SERVICIOS DE CERTIFICACION ELECTRONICA'),
(413, 'GESTION DE ASOCIADOS O MIEMBROS DE PARTIDOS POLITICOS, SINDICATOS, IGLESIAS, CONFESIONES O COMUNIDADES RELIGIOSAS Y ASOCIACIONES, FUNDADIONES Y OTRAS ENTIDADES SIN ANIMO DE LUCRO, CUYA FINALIDAD SEA POLITICA, FILOSOFICA, RELIGIOSA O SINDICAL'),
(414, 'GESTION DE ACTIVIDADES ASOCIATIVAS, CULTURALES, RECREATIVAS, DEPORTIVAS Y SOCIALES'),
(415, 'GESTION DE ASISTENCIA SOCIAL'),
(416, 'EDUCACION'),
(417, 'INVESTIGACION EPIDEMOLOGICA Y ACTIVIDADES ANALOGAS'),
(418, 'GESTION Y CONTROL SANITARIO'),
(419, 'HISTORIAL CLINICO'),
(420, 'SEGURIDAD PRIVADA'),
(421, 'SEGURIDAD Y CONTROL DE ACCESO A EDIFICIOS'),
(422, 'VIDEOVIGILANCIA'),
(423, 'FINES ESTADISTICOS, HISTORICOS O CIENTIFICOS'),
(499, 'OTRAS FINALIDADES');

-- --------------------------------------------------------

--
-- Table structure for table `taula3`
--

DROP TABLE IF EXISTS `taula3`;
CREATE TABLE IF NOT EXISTS `taula3` (
  `t3id` varchar(3) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`t3id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula3`
--

INSERT INTO `taula3` (`t3id`, `descripcion`) VALUES
('01', 'EMPLEADOS'),
('02', 'CLIENTES Y USUARIOS'),
('03', 'PROVEEDORES'),
('04', 'ASOCIADOS O MIEMBROS'),
('05', 'PROPIETARIOS O ARRENDATARIOS'),
('06', 'PACIENTES'),
('07', 'ESTUDIANTES'),
('08', 'PERSONAS DE CONTACTO'),
('09', 'PADRES O TUTORES'),
('10', 'REPRESENTANTE LEGAL'),
('11', 'SOLICITANTES'),
('12', 'BENEFICIARIOS'),
('13', 'CARGOS PUBLICOS');

-- --------------------------------------------------------

--
-- Table structure for table `taula4`
--

DROP TABLE IF EXISTS `taula4`;
CREATE TABLE IF NOT EXISTS `taula4` (
  `t4id` int(11) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`t4id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula4`
--

INSERT INTO `taula4` (`t4id`, `descripcion`) VALUES
(1, 'CARACTERISTICAS PERSONALES'),
(2, 'CIRCUNSTANCIAS SOCIALES'),
(3, 'ACADEMICOS Y PROFESIONALES'),
(4, 'DETALLES DEL EMPLEO'),
(5, 'INFORMACION COMERCIAL'),
(6, 'ECONOMICOS, FINANCIEROS Y DE SEGUROS'),
(7, 'TRANSACCIONES DE BIENES Y SERVICIOS');

-- --------------------------------------------------------

--
-- Table structure for table `taula5`
--

DROP TABLE IF EXISTS `taula5`;
CREATE TABLE IF NOT EXISTS `taula5` (
  `t5id` varchar(5) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`t5id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula5`
--

INSERT INTO `taula5` (`t5id`, `descripcion`) VALUES
('01', 'ORGANIZACIONES O PERSONAS DIRECTAMENTE RELACIONADAS CON EL RESPONSABLE'),
('02', 'ORGANISMOS DE LA SEGURIDAD SOCIAL'),
('03', 'REGISTROS PUBLICOS'),
('04', 'COLEGIOS PROFESIONALES'),
('05', 'ADMINISTRACION TRIBUTARIA'),
('06', 'OTROS ORGANOS DE LA ADMINISTRACION PUBLICA'),
('07', 'COMISION NACIONAL DEL MERCADO DE VALORES'),
('08', 'COMISION NACI0NAL DEL JUEGO'),
('09', 'NOTARIOS Y PROCURADORES'),
('10', 'FUERZAS Y CUERPOS DE SEGURIDAD'),
('11', 'ORGANISMOS DE LA UNION EUROPEA'),
('12', 'ENTIDADES DEDICADAS AL CUMPLIMIENTO O INCUMPLIMIENTO DE OBLIGACIONES DINERARIAS'),
('13', 'BANCOS, CAJAS DE AHORROS Y CAJAS RURALES'),
('14', 'ENTIDADES ASEGURADORAS'),
('15', 'OTRAS ENTIDADES FINANCIERAS'),
('16', 'ENTIDADES SANITARIAS'),
('17', 'PRESTACIONES DE SERVICIOS DE TELECOMUNICACIONES'),
('18', 'EMPRESAS DEDICADAS A PUBLICIDAD O MARKETING DIRECTO'),
('19', 'ASOCIACIONES Y ORGANIZACIONES SIN ANIMO DE LUCRO'),
('20', 'SINDICATOS Y JUNTAS DE PERSONAL'),
('21', 'ADMINISTRACION CON COMPETENCIA EN LA MATERIA');

-- --------------------------------------------------------

--
-- Table structure for table `taula7`
--

DROP TABLE IF EXISTS `taula7`;
CREATE TABLE IF NOT EXISTS `taula7` (
  `t7id` varchar(5) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`t7id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taula7`
--

INSERT INTO `taula7` (`t7id`, `descripcion`) VALUES
('01', 'COMPAÑIAS FILIALES'),
('02', 'COMPAÑIA MATRIZ'),
('03', 'COMPAÑIAS DEL GRUPO'),
('04', 'PRESTADORES DE SERVICIO'),
('05', 'UNIVERSIDADES Y CENTROS EDUCATIVOS'),
('06', 'ORGANOS PUBLICOS DE OTROS ESTADOS'),
('07', 'ORGANISMOS INTERNACIONALES'),
('08', 'ENTIDADES SANITARIAS'),
('09', 'ORGANOS JUDICIALES'),
('10', 'ENTIDADES FINANCIERAS'),
('11', 'DATOS DE PASAJEROS CON DESTINO A LOS ORGANISMOS DE FRONTERAS DE EEUU Y CANADA');

-- --------------------------------------------------------

--
-- Table structure for table `tipos_colectivos`
--

DROP TABLE IF EXISTS `tipos_colectivos`;
CREATE TABLE IF NOT EXISTS `tipos_colectivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `left_colectivos` text COLLATE utf8_unicode_ci,
  `right_colectivos` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tipos_colectivos`
--

INSERT INTO `tipos_colectivos` (`id`, `left_colectivos`, `right_colectivos`) VALUES
(1, '01,02,03,08,10', '05'),
(2, '05,08', '02,03'),
(3, '09', '06'),
(4, '', '01'),
(5, '09', '06'),
(6, '08,09', '07'),
(7, '', '01,02,03');

-- --------------------------------------------------------

--
-- Table structure for table `tipos_datos_seguridad_cesion`
--

DROP TABLE IF EXISTS `tipos_datos_seguridad_cesion`;
CREATE TABLE IF NOT EXISTS `tipos_datos_seguridad_cesion` (
  `id` int(11) NOT NULL,
  `datos_check` text COLLATE utf8_unicode_ci,
  `datos_select_izq` text COLLATE utf8_unicode_ci,
  `datos_select_der` text COLLATE utf8_unicode_ci,
  `medidas_check` text COLLATE utf8_unicode_ci,
  `medidas_select_izq` text COLLATE utf8_unicode_ci,
  `medidas_select_der` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tipos_datos_seguridad_cesion`
--

INSERT INTO `tipos_datos_seguridad_cesion` (`id`, `datos_check`, `datos_select_izq`, `datos_select_der`, `medidas_check`, `medidas_select_izq`, `medidas_select_der`) VALUES
(1, '8,10,12,13', '01', '02,05,06,07', '19,22', '02,05,06,15', '01,13'),
(2, '8,10,12,13', '03,04', '01,02,05,06,07', '19,22', '06,10,12,15,18', '01,05,13'),
(3, '6,8,10,12', '01', '02,05,06,07', '21,24', '04,06', '16'),
(4, '8,9,10,12,13', NULL, '01,03,04,06,07', '19,22', '01,04,06,15,16', '02,05,13,14'),
(5, '6,8,9,10,11,12,13', '03,04', '01,02', '21,24', '06', '14,16'),
(6, '8,10,11,12,13', '01,03,04', NULL, '21,22', '01,02,05,06,13,14,21', NULL),
(7, '15', NULL, NULL, '19,22', NULL, '10');

-- --------------------------------------------------------

--
-- Table structure for table `tipos_finalidades`
--

DROP TABLE IF EXISTS `tipos_finalidades`;
CREATE TABLE IF NOT EXISTS `tipos_finalidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `left_finalidades` text COLLATE utf8_unicode_ci NOT NULL,
  `right_finalidades` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tipos_finalidades`
--

INSERT INTO `tipos_finalidades` (`id`, `name`, `description`, `left_finalidades`, `right_finalidades`) VALUES
(1, 'Comunidad de propietarios', 'Gestión de los datos de la comunidad de propietarios', '402,499', '400'),
(2, 'Clientes y/o proveedores', 'Gestión de clientes y/o proveedores', '408,411,499', '400'),
(3, 'Libro recetario', 'Gestión de los datos de dispensación de medicamentos, psicotropicos y de estupefacientes', '499', '418'),
(4, 'Nóminas, personal y recursos humanos', 'Gestión de nóminas y recursos humanos', '402,403,499', '401'),
(5, 'Pacientes (Historial clínico)', 'Gestión de los datos de los pacientes y de su historia clinica y de las tareas administrativas derivadas de la prestación asistencial', '417,499', '418,419'),
(6, 'Gestión escolar', 'Gestión escolar del centro', '414,499', '416'),
(7, 'Videovigilancia', 'Videovigilancia de las instalaciones', '420,421,499', '422');

-- --------------------------------------------------------

--
-- Table structure for table `trans_unit`
--

DROP TABLE IF EXISTS `trans_unit`;
CREATE TABLE IF NOT EXISTS `trans_unit` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) DEFAULT NULL,
  `id` varchar(255) DEFAULT NULL,
  `source` text,
  `target` text,
  `comments` text,
  `date_added` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `translated` int(11) DEFAULT NULL,
  PRIMARY KEY (`msg_id`),
  KEY `trans_unit_FI_1` (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2696 ;

--
-- Dumping data for table `trans_unit`
--

INSERT INTO `trans_unit` (`msg_id`, `cat_id`, `id`, `source`, `target`, `comments`, `date_added`, `date_modified`, `author`, `translated`) VALUES
(1891, 1, '1', 'Esta seguro de que desea salir de la aplicación', 'Esta seguro de que desea salir de la aplicación', NULL, '2009-06-03 13:30:01', '2009-06-03 13:30:01', NULL, 1),
(1893, 1, '3', 'Acerca de Legedia', 'Acerca de Legedia', NULL, '2009-06-02 12:38:48', '2009-06-02 12:38:48', NULL, 1),
(1894, 1, '4', 'Informe acerca de un error', 'Informe acerca de un error', NULL, '2009-06-03 16:11:08', '2009-06-03 16:11:08', NULL, 1),
(1895, 1, '5', 'primero', 'primero', NULL, '2009-06-02 13:15:59', '2009-06-02 13:15:59', NULL, 1),
(1896, 1, '6', 'previo', 'previo', NULL, '2009-06-02 13:15:34', '2009-06-02 13:15:34', NULL, 1),
(1897, 1, '7', 'siguiente', 'Siguiente', NULL, '2009-06-02 13:07:39', '2009-06-02 13:07:39', NULL, 1),
(1899, 1, '9', 'ok', 'OK', NULL, '2009-06-02 13:19:30', '2009-06-02 13:19:30', NULL, 1),
(1900, 1, '10', 'error', 'error', NULL, '2009-06-03 13:29:44', '2009-06-03 13:29:44', NULL, 1),
(1901, 1, '11', 'Si', 'Si', NULL, '2009-06-02 13:06:55', '2009-06-02 13:06:55', NULL, 1),
(1902, 1, '12', 'No', 'No', NULL, '2009-06-02 13:22:18', '2009-06-02 13:22:18', NULL, 1),
(1903, 1, '13', 'desde %1% hasta %2%', 'desde %1% hasta %2%', NULL, '2009-06-03 13:24:00', '2009-06-03 13:24:00', NULL, 1),
(1904, 1, '14', 'más de %1%', 'más de %1%', NULL, '2009-06-03 16:17:50', '2009-06-03 16:17:50', NULL, 1),
(1905, 1, '15', 'menos de %2%', 'menos de %2%', NULL, '2009-06-03 16:26:21', '2009-06-03 16:26:21', NULL, 1),
(1906, 1, '16', 'primer', 'primer', NULL, '2009-06-02 13:15:47', '2009-06-02 13:15:47', NULL, 1),
(1907, 1, '17', 'segundo', 'segundo', NULL, '2009-06-02 13:12:20', '2009-06-02 13:12:20', NULL, 1),
(1908, 1, '18', 'tercer', 'tercer', NULL, '2009-06-02 13:08:19', '2009-06-02 13:08:19', NULL, 1),
(1909, 1, '19', 'cuarto', 'cuarto', NULL, '2009-06-03 13:20:04', '2009-06-03 13:20:04', NULL, 1),
(1910, 1, '20', 'quinto', 'quinto', NULL, '2009-06-02 13:10:52', '2009-06-02 13:10:52', NULL, 1),
(1911, 1, '21', 'sexto', 'sexto', NULL, '2009-06-02 13:06:32', '2009-06-02 13:06:32', NULL, 1),
(1912, 1, '22', '%1% %2%', '%1% %2%', NULL, '2009-06-02 12:32:59', '2009-06-02 12:32:59', NULL, 1),
(1913, 1, '23', '%posicion% %periodo%', '%posicion% %periodo%', NULL, '2009-06-02 12:37:16', '2009-06-02 12:37:16', NULL, 1),
(1914, 1, '24', '%periodo% de %year%', '%periodo% de %year%', NULL, '2009-06-02 12:31:21', '2009-06-02 12:31:21', NULL, 1),
(1915, 1, '25', 'si o no', 'Si o No', NULL, '2009-06-02 13:07:30', '2009-06-02 13:07:30', NULL, 1),
(1916, 1, '26', 'desde', 'desde', NULL, '2009-06-03 13:23:44', '2009-06-03 13:23:44', NULL, 1),
(1917, 1, '27', 'hasta', 'hasta', NULL, '2009-06-03 16:09:33', '2009-06-03 16:09:33', NULL, 1),
(1918, 1, '28', 'Vista preliminar del informe', 'Vista preliminar del informe', NULL, '2009-06-02 12:59:47', '2009-06-02 12:59:47', NULL, 1),
(1919, 1, '29', 'Editar datos de correo electrónico', 'Editar datos de correo electrónico', NULL, '2009-06-03 13:26:17', '2009-06-03 13:26:17', NULL, 1),
(1920, 1, '30', 'Datos', 'Datos', NULL, '2009-06-03 13:20:13', '2009-06-03 13:20:13', NULL, 1),
(1921, 1, '31', 'tablas', 'Tablas', NULL, '2009-06-02 13:08:13', '2009-06-02 13:08:13', NULL, 1),
(1922, 1, '32', 'Dirección', 'Dirección', NULL, '2009-06-03 13:24:48', '2009-06-03 13:24:48', NULL, 1),
(1923, 1, '33', 'Configuración', 'Configuración', NULL, '2009-06-03 13:18:27', '2009-06-03 13:18:27', NULL, 1),
(1926, 1, '36', '[0] no hay resultados|[1] 1 resultado|(1,+Inf] %1% resultados', '[0] Sin resultados|[1] 1 resultado|(1,+Inf] %1% resultados', NULL, '2009-06-02 12:59:07', '2009-06-02 12:59:07', NULL, 1),
(1927, 1, '37', 'Lista de empresas', 'Lista de empresas', NULL, '2009-06-03 16:13:44', '2009-06-03 16:13:44', NULL, 1),
(1929, 1, '39', 'editar', 'editar', NULL, '2009-06-03 13:27:04', '2009-06-03 13:27:04', NULL, 1),
(1930, 1, '40', 'Error al validar el formulario', 'Error al validar el formulario', NULL, '2009-06-03 13:29:52', '2009-06-03 13:29:52', NULL, 1),
(1931, 1, '41', 'Logo', 'Logo', NULL, '2009-06-03 16:16:18', '2009-06-03 16:16:18', NULL, 1),
(1932, 1, '42', 'Id', 'Id', NULL, '2009-06-03 16:09:48', '2009-06-03 16:09:48', NULL, 1),
(1933, 1, '43', 'Nombre', 'Nombre', NULL, '2009-06-02 13:23:42', '2009-06-02 13:23:42', NULL, 1),
(1934, 1, '44', 'Domicilio', 'Domicilio', NULL, '2009-06-03 13:25:16', '2009-06-03 13:25:16', NULL, 1),
(1935, 1, '45', 'Poblacion', 'Población', NULL, '2009-06-02 13:20:24', '2009-06-02 13:20:24', NULL, 1),
(1936, 1, '46', 'C.P.', 'C.P.', NULL, '2009-06-02 12:55:57', '2009-06-02 12:55:57', NULL, 1),
(1937, 1, '47', 'Provincia', 'Provincia', NULL, '2009-06-02 13:10:29', '2009-06-02 13:10:29', NULL, 1),
(1938, 1, '48', 'Usuario', 'Usuario', NULL, '2009-06-02 13:02:05', '2009-06-02 13:02:05', NULL, 1),
(1941, 1, '51', 'editar', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL),
(1944, 1, '54', 'Editar empresa', 'Editar empresa', NULL, '2009-06-03 13:28:35', '2009-06-03 13:28:35', NULL, 1),
(1945, 1, '55', 'Datos SMTP', 'Datos SMTP', NULL, '2009-06-03 13:22:23', '2009-06-03 13:22:23', NULL, 1),
(1946, 1, '56', 'Dirección del servidor', 'Dirección del servidor', NULL, '2009-06-03 13:25:08', '2009-06-03 13:25:08', NULL, 1),
(1947, 1, '57', 'Nombre de usuario', 'Nombre de usuario', NULL, '2009-06-02 13:18:53', '2009-06-02 13:18:53', NULL, 1),
(1948, 1, '58', 'Marque si desea cambiar la clave', 'Marque si desea cambiar la clave', NULL, '2009-06-03 16:17:32', '2009-06-03 16:17:32', NULL, 1),
(1949, 1, '59', 'Introduzca la nueva clave', 'Introduzca la nueva clave', NULL, '2009-06-03 16:12:30', '2009-06-03 16:12:30', NULL, 1),
(1950, 1, '60', 'Número de puerto. Normalmente es el 25.', 'Número de puerto. Normalmente es el 25.', NULL, '2009-06-02 13:21:59', '2009-06-02 13:21:59', NULL, 1),
(1951, 1, '61', 'Datos de envío', 'Datos de envío', NULL, '2009-06-03 13:21:24', '2009-06-03 13:21:24', NULL, 1),
(1952, 1, '62', 'Dirección de correo remitente', 'Dirección de correo remitente', NULL, '2009-06-03 13:24:55', '2009-06-03 13:24:55', NULL, 1),
(1953, 1, '63', 'Nombre del remitente', 'Nombre del remitente', NULL, '2009-06-02 13:18:57', '2009-06-02 13:18:57', NULL, 1),
(1954, 1, '64', 'Datos de la empresa', 'Datos de la empresa', NULL, '2009-06-03 13:21:28', '2009-06-03 13:21:28', NULL, 1),
(1955, 1, '65', 'crear', 'crear', NULL, '2009-06-03 13:19:26', '2009-06-03 13:19:26', NULL, 1),
(1956, 1, '66', 'Lista', 'Lista', NULL, '2009-06-03 16:13:21', '2009-06-03 16:13:21', NULL, 1),
(1957, 1, '67', 'guardar', 'guardar', NULL, '2009-06-03 15:55:24', '2009-06-03 15:55:24', NULL, 1),
(1958, 1, '68', 'Guardar y añadir', 'Guardar y añadir', NULL, '2009-06-02 15:36:07', '2009-06-02 15:36:07', NULL, 1),
(1959, 1, '69', 'Configuración de correo electrónico', 'Configuración de correo electrónico', NULL, '2009-06-03 13:18:37', '2009-06-03 13:18:37', NULL, 1),
(1960, 1, '70', 'Servidor SMTP', 'Servidor SMTP', NULL, '2009-06-02 13:05:36', '2009-06-02 13:05:36', NULL, 1),
(1961, 1, '71', 'Configurar correo', 'Configurar correo', NULL, '2009-06-03 13:18:42', '2009-06-03 13:18:42', NULL, 1),
(1962, 1, '72', 'empresa', 'empresa', NULL, '2009-06-03 13:29:11', '2009-06-03 13:29:11', NULL, 1),
(1963, 1, '73', 'no hay resultados', 'no hay resultados', NULL, '2009-06-02 13:23:21', '2009-06-02 13:23:21', NULL, 1),
(1964, 1, '74', 'No hay logo definido', 'No hay logo definido', NULL, '2009-06-02 13:23:03', '2009-06-02 13:23:03', NULL, 1),
(1965, 1, '75', 'Logotipo', 'Logotipo', NULL, '2009-06-03 16:16:23', '2009-06-03 16:16:23', NULL, 1),
(1966, 1, '76', 'Seleccione el logotipo de la empresa', 'Seleccione el logotipo de la empresa', NULL, '2009-06-02 13:12:29', '2009-06-02 13:12:29', NULL, 1),
(1967, 1, '77', 'Volver a empresa', 'Volver a empresa', NULL, '2009-06-02 12:59:34', '2009-06-02 12:59:34', NULL, 1),
(1968, 1, '78', 'No ha podido borrarse el objeto', 'No ha podido borrarse el objeto', NULL, '2009-06-02 13:22:28', '2009-06-02 13:22:28', NULL, 1),
(1969, 1, '79', 'Error 404 - No encontrado', 'Error 404 - No encontrado', NULL, '2009-06-03 13:29:48', '2009-06-03 13:29:48', NULL, 1),
(1970, 1, '80', 'Introduzca su nombre de usuario y su clave. (Ud. no tiene permisos para ', 'Introduzca su nombre de usuario y su clave. (Ud. no tiene permisos para ', NULL, '2009-06-03 16:12:34', '2009-06-03 16:12:34', NULL, 1),
(1971, 1, '81', 'Bienvenido a Legedia ', 'Bienvenido a Legedia ', NULL, '2009-06-02 12:50:36', '2009-06-02 12:50:36', NULL, 1),
(1972, 1, '82', 'usuario', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL),
(1973, 1, '83', 'contraseña', 'contraseña', NULL, '2009-06-03 13:19:04', '2009-06-03 13:19:04', NULL, 1),
(1974, 1, '84', 'Entrar', 'Entrar', NULL, '2009-06-03 13:29:19', '2009-06-03 13:29:19', NULL, 1),
(1975, 1, '85', 'No tiene permisos para acceder a la sección indicada', 'No tiene permisos para acceder a la sección indicada', NULL, '2009-06-02 13:23:38', '2009-06-02 13:23:38', NULL, 1),
(1976, 1, '86', 'Actions', 'Acciones', NULL, '2009-06-02 12:37:50', '2009-06-02 12:37:50', NULL, 1),
(1977, 1, '87', 'First', 'Primero', NULL, '2009-06-03 15:54:56', '2009-06-03 15:54:56', NULL, 1),
(1978, 1, '88', 'Previous', 'Previo', NULL, '2009-06-02 13:15:42', '2009-06-02 13:15:42', NULL, 1),
(1979, 1, '89', 'Next', 'Siguiente', NULL, '2009-06-02 13:22:09', '2009-06-02 13:22:09', NULL, 1),
(1980, 1, '90', 'Last', 'Último', NULL, '2009-06-03 16:12:53', '2009-06-03 16:12:53', NULL, 1),
(1981, 1, '91', '[0] no result|[1] 1 result|(1,+Inf] %1% results', '[0] Sin resultados|[1] 1 resultado|(1,+Inf] %1% resultados', NULL, '2009-06-02 12:58:46', '2009-06-02 12:58:46', NULL, 1),
(1982, 1, '92', 'Sesion', 'Sesion', NULL, '2009-06-02 13:05:42', '2009-06-02 13:05:42', NULL, 1),
(1983, 1, '93', 'delete', 'Borrar', NULL, '2009-06-03 13:23:33', '2009-06-03 13:23:33', NULL, 1),
(1984, 1, '94', 'Are you sure?', 'Are you sure?', NULL, '2009-06-02 12:43:17', '2009-06-02 12:43:17', NULL, 1),
(1985, 1, '95', 'show', 'Mostrar', NULL, '2009-06-02 13:06:38', '2009-06-02 13:06:38', NULL, 1),
(1986, 1, '96', 'filters', 'Filtros', NULL, '2009-06-03 15:54:28', '2009-06-03 15:54:28', NULL, 1),
(1987, 1, '97', 'Sesion:', 'Sesión:', NULL, '2009-06-02 13:05:57', '2009-06-02 13:05:57', NULL, 1),
(1988, 1, '98', 'reset', 'Reiniciar', NULL, '2009-06-02 13:11:34', '2009-06-02 13:11:34', NULL, 1),
(1989, 1, '99', 'filter', 'Filtrar', NULL, '2009-06-03 15:54:21', '2009-06-03 15:54:21', NULL, 1),
(1990, 1, '100', 'create', 'crear', NULL, '2009-06-03 13:19:58', '2009-06-03 13:19:58', NULL, 1),
(1991, 1, '101', 'Lista de Sesiones', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL),
(1992, 1, '102', 'no result', 'no result', NULL, '2009-06-02 13:23:30', '2009-06-02 13:23:30', NULL, 1),
(1993, 1, '103', 'Could not delete the selected %name%', 'Could not delete the selected %name%', NULL, '2009-06-03 13:19:21', '2009-06-03 13:19:21', NULL, 1),
(1994, 1, '104', 'Cambiar', 'Cambiar', NULL, '2009-06-02 12:55:47', '2009-06-02 12:55:47', NULL, 1),
(1995, 1, '105', 'Nota: Cambiar el nombre de un parámetro puede alterar su significado', 'Nota: Cambiar el nombre de un parámetro puede alterar su significado', NULL, '2009-06-02 13:19:05', '2009-06-02 13:19:05', NULL, 1),
(1996, 1, '106', 'Modificar', 'Modificar', NULL, '2009-06-02 13:21:43', '2009-06-02 13:21:43', NULL, 1),
(1997, 1, '107', 'add', 'Añadir', NULL, '2009-06-02 12:40:49', '2009-06-02 12:40:49', NULL, 1),
(1998, 1, '108', 'Se dispone a guardar los datos como un objeto nuevo. ¿Estas seguro?', 'Se dispone a guardar los datos como un objeto nuevo. ¿Estas seguro?', NULL, '2009-06-02 13:12:15', '2009-06-02 13:12:15', NULL, 1),
(1999, 1, '109', 'Guardar como nuevo', 'Guardar como nuevo', NULL, '2009-06-03 15:56:52', '2009-06-03 15:56:52', NULL, 1),
(2000, 1, '110', 'Va a cancelar todos los cambios que haya podido hacer, esta seguro de continuar?', 'Va a cancelar todos los cambios que haya podido hacer, esta seguro de continuar?', NULL, '2009-06-02 13:01:41', '2009-06-02 13:01:41', NULL, 1),
(2001, 1, '111', 'Cancelar', 'Cancelar', NULL, '2009-06-03 13:16:14', '2009-06-03 13:16:14', NULL, 1),
(2002, 1, '112', 'Lista de parámetros', 'Lista de parámetros', NULL, '2009-06-03 16:14:04', '2009-06-03 16:14:04', NULL, 1),
(2003, 1, '113', 'Ver %1%', 'Ver %1%', NULL, '2009-06-02 13:01:18', '2009-06-02 13:01:18', NULL, 1),
(2005, 1, '115', 'Estas seguro?', '¿Estas seguro?', NULL, '2009-06-03 13:30:14', '2009-06-03 13:30:14', NULL, 1),
(2006, 1, '116', 'Borrar', 'Borrar', NULL, '2009-06-02 12:50:46', '2009-06-02 12:50:46', NULL, 1),
(2007, 1, '117', 'Nuevo', 'Nuevo', NULL, '2009-06-02 13:19:15', '2009-06-02 13:19:15', NULL, 1),
(2008, 1, '118', 'Parámetros Generales', 'Parámetros Generales', NULL, '2009-06-02 13:19:56', '2009-06-02 13:19:56', NULL, 1),
(2009, 1, '119', 'No hay fichero definido', 'No hay fichero definido', NULL, '2009-06-02 13:22:58', '2009-06-02 13:22:58', NULL, 1),
(2010, 1, '120', 'Datos de acceso', 'Datos de acceso', NULL, '2009-06-03 13:21:17', '2009-06-03 13:21:17', NULL, 1),
(2011, 1, '121', 'Introduce una contraseña para modificar su valor o dejalo vací­o para mantener la contraseña actual', 'Introduce una contraseña para modificar su valor o dejalo vací­o para mantener la contraseña actual', NULL, '2009-06-03 16:11:30', '2009-06-03 16:11:30', NULL, 1),
(2012, 1, '122', 'Editar usuario', 'Editar usuario', NULL, '2009-06-03 13:28:49', '2009-06-03 13:28:49', NULL, 1),
(2013, 1, '123', 'Datos del usuario', 'Datos del usuario', NULL, '2009-06-03 13:22:14', '2009-06-03 13:22:14', NULL, 1),
(2014, 1, '124', 'Preferencias', 'Preferencias', NULL, '2009-06-02 13:15:25', '2009-06-02 13:15:25', NULL, 1),
(2015, 1, '125', 'Datos personales', 'Datos personales', NULL, '2009-06-03 13:22:19', '2009-06-03 13:22:19', NULL, 1),
(2017, 1, '127', 'vací­o', 'vací­o', NULL, '2009-06-02 13:01:35', '2009-06-02 13:01:35', NULL, 1),
(2018, 1, '128', 'list', 'Listar', NULL, '2009-06-03 16:14:24', '2009-06-03 16:14:24', NULL, 1),
(2019, 1, '129', 'Módulo', 'Módulo', NULL, '2009-06-03 16:19:16', '2009-06-03 16:19:16', NULL, 1),
(2021, 1, '131', 'Ver acciones', 'Ver acciones', NULL, '2009-06-02 13:01:13', '2009-06-02 13:01:13', NULL, 1),
(2022, 1, '132', 'Log', 'Log', NULL, '2009-06-03 16:16:12', '2009-06-03 16:16:12', NULL, 1),
(2023, 1, '133', 'Otros Datos', 'Otros Datos', NULL, '2009-06-02 13:19:42', '2009-06-02 13:19:42', NULL, 1),
(2024, 1, '134', 'Parámetros', 'Parámetros', NULL, '2009-06-02 13:19:50', '2009-06-02 13:19:50', NULL, 1),
(2025, 1, '135', 'Mensaje', 'Mensaje', NULL, '2009-06-02 13:21:37', '2009-06-02 13:21:37', NULL, 1),
(2026, 1, '136', 'Sesiones', 'Sesiones', NULL, '2009-06-02 13:06:02', '2009-06-02 13:06:02', NULL, 1),
(2027, 1, '137', 'Lista de Acciones', 'Lista de acciones', NULL, '2009-06-03 16:14:31', '2009-06-03 16:14:31', NULL, 1),
(2028, 1, '138', 'translated', 'traducidos', NULL, '2009-06-03 16:27:59', '2009-06-03 16:27:59', NULL, 1),
(2029, 1, '139', 'Set translation to source string', 'Establecer la traduccion como la cadena origen', NULL, '2009-06-03 16:31:07', '2009-06-03 16:31:07', NULL, 1),
(2030, 1, '140', 'all', 'Todos', NULL, '2009-06-02 12:41:13', '2009-06-02 12:41:13', NULL, 1),
(2031, 1, '141', 'untranslated', 'Sin Traducir', NULL, '2009-06-02 13:02:13', '2009-06-02 13:02:13', NULL, 1),
(2033, 1, '143', 'The form is not valid because it contains some errors.', 'El formulario no es valido porque contiene errores.', NULL, '2009-06-02 13:03:54', '2009-06-02 13:03:54', NULL, 1),
(2034, 1, '144', 'edit', 'Editar', NULL, '2009-06-03 13:26:38', '2009-06-03 13:26:38', NULL, 1),
(2035, 1, '145', 'Edit Translation', 'Editar traduccion', NULL, '2009-06-03 16:30:38', '2009-06-03 16:30:38', NULL, 1),
(2036, 1, '146', 'save', 'Guardar', NULL, '2009-06-02 13:11:46', '2009-06-02 13:11:46', NULL, 1),
(2037, 1, '147', 'save and list', 'Guardar y listar', NULL, '2009-06-02 13:12:08', '2009-06-02 13:12:08', NULL, 1),
(2038, 1, '148', 'Translation list', 'Lista de traducciones', NULL, '2009-06-02 13:02:37', '2009-06-02 13:02:37', NULL, 1),
(2039, 1, '149', 'Si', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL),
(2041, 1, '151', 'accesos directos', 'accesos directos', NULL, '2009-06-02 12:38:59', '2009-06-02 12:38:59', NULL, 1),
(2042, 1, '152', 'Ver Campos', 'Ver Campos', NULL, '2009-06-02 13:00:08', '2009-06-02 13:00:08', NULL, 1),
(2046, 1, '156', 'registros', 'registros', NULL, '2009-06-02 13:11:02', '2009-06-02 13:11:02', NULL, 1),
(2047, 1, '157', 'Editar tablas', 'Editar tablas', NULL, '2009-06-03 13:28:44', '2009-06-03 13:28:44', NULL, 1),
(2048, 1, '158', 'Datos de las tablas', 'Datos de las tablas', NULL, '2009-06-03 13:21:49', '2009-06-03 13:21:49', NULL, 1),
(2049, 1, '159', 'empresa', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL),
(2050, 1, '160', 'Crear nueva tabla', 'Crear nueva tabla', NULL, '2009-06-03 13:19:32', '2009-06-03 13:19:32', NULL, 1),
(2051, 1, '161', 'lista de tablas', 'lista de tablas', NULL, '2009-06-03 16:15:57', '2009-06-03 16:15:57', NULL, 1),
(2052, 1, '162', 'Historial de seleccionados', 'Historial de seleccionados', NULL, '2009-06-03 16:09:38', '2009-06-03 16:09:38', NULL, 1),
(2053, 1, '163', 'Fuente de datos', 'Fuente de datos', NULL, '2009-06-03 15:55:16', '2009-06-03 15:55:16', NULL, 1),
(2055, 1, '165', 'crear una nueva fuente de datos', 'crear una nueva fuente de datos', NULL, '2009-06-03 13:19:44', '2009-06-03 13:19:44', NULL, 1),
(2056, 1, '166', 'Nuevo idioma', 'Nuevo idioma', NULL, '2009-06-02 13:19:19', '2009-06-02 13:19:19', NULL, 1),
(2057, 1, '167', 'save and add', 'Guardar y anadir', NULL, '2009-06-02 15:35:57', '2009-06-02 15:35:57', NULL, 1),
(2058, 1, '168', 'Lista de idiomas', 'Lista de idiomas', NULL, '2009-06-03 16:13:57', '2009-06-03 16:13:57', NULL, 1),
(2059, 1, '169', 'Permisos', 'Permisos', NULL, '2009-06-02 13:20:07', '2009-06-02 13:20:07', NULL, 1),
(2060, 1, '170', 'del', 'del', NULL, '2009-06-03 13:23:08', '2009-06-03 13:23:08', NULL, 1),
(2061, 1, '171', 'There are some errors that prevent the form to validate', 'Se han detectado errores cuando se estaba validando el formulario', NULL, '2009-06-02 13:03:37', '2009-06-02 13:03:37', NULL, 1),
(2062, 1, '172', 'Edición del Grupo :: ', 'Edición del Grupo :: ', NULL, '2009-06-03 13:25:28', '2009-06-03 13:25:28', NULL, 1),
(2063, 1, '173', 'Vista del Grupo :: ', 'Vista del Grupo :: ', NULL, '2009-06-02 12:59:53', '2009-06-02 12:59:53', NULL, 1),
(2064, 1, '174', 'Lista de Grupos', 'Lista de grupos', NULL, '2009-06-03 16:14:36', '2009-06-03 16:14:36', NULL, 1),
(2065, 1, '175', 'Sin Resultados', 'Sin Resultados', NULL, '2009-06-02 13:07:53', '2009-06-02 13:07:53', NULL, 1),
(2066, 1, '176', 'Notas', 'Notas', NULL, '2009-06-02 13:19:10', '2009-06-02 13:19:10', NULL, 1),
(2067, 1, '177', 'No hay notas', 'No hay notas', NULL, '2009-06-02 13:23:08', '2009-06-02 13:23:08', NULL, 1),
(2069, 1, '179', 'Enviar nuevo mensaje', 'Enviar nuevo mensaje', NULL, '2009-06-03 13:29:40', '2009-06-03 13:29:40', NULL, 1),
(2070, 1, '180', 'Bandeja de entrada', 'Bandeja de entrada', NULL, '2009-06-02 12:48:50', '2009-06-02 12:48:50', NULL, 1),
(2071, 1, '181', 'No hay nuevos mensajes', 'No hay nuevos mensajes', NULL, '2009-06-02 13:23:12', '2009-06-02 13:23:12', NULL, 1),
(2072, 1, '182', 'Bienvenido ', 'Bienvenido ', NULL, '2009-06-02 12:50:32', '2009-06-02 12:50:32', NULL, 1),
(2074, 1, '184', ' registros', ' registros', NULL, '2009-06-02 12:30:45', '2009-06-02 12:30:45', NULL, 1),
(2075, 1, '185', '[0] no hay mensajes|[1] hay 1 mensaje|(1,+Inf] hay %1% mensajes', '[0] Sin mensajes|[1] hay 1 mensaje|(1,+Inf] hay %1% mensajes', NULL, '2009-06-02 12:59:30', '2009-06-02 12:59:30', NULL, 1),
(2076, 1, '186', '[0] no hay notas|[1] hay 1 nota|(1,+Inf] hay %1% notas', '[0] Sin notas|[1] hay 1 nota|(1,+Inf] hay %1% notas', NULL, '2009-06-02 12:59:19', '2009-06-02 12:59:19', NULL, 1),
(2077, 1, '187', 'No ha introducido ningun dato para el campo ''%1%''', 'No ha introducido ningun dato para el campo ''%1%''', NULL, '2009-06-02 13:22:23', '2009-06-02 13:22:23', NULL, 1),
(2078, 1, '188', 'No ha seleccionado ningun dato para el campo ''%1%''', 'No ha seleccionado ningun dato para el campo ''%1%''', NULL, '2009-06-02 13:22:54', '2009-06-02 13:22:54', NULL, 1),
(2079, 1, '189', 'El valor del campo ''%1%'' no es un número', 'El valor del campo ''%1%'' no es un número', NULL, '2009-06-03 13:28:58', '2009-06-03 13:28:58', NULL, 1),
(2080, 1, '190', 'Registros Relacionados de', 'Registros Relacionados de', NULL, '2009-06-02 13:11:10', '2009-06-02 13:11:10', NULL, 1),
(2081, 1, '191', 'Datos del cliente', 'Datos del cliente', NULL, '2009-06-03 13:22:04', '2009-06-03 13:22:04', NULL, 1),
(2082, 1, '192', 'Nombre completo', 'Nombre completo', NULL, '2009-06-02 13:18:48', '2009-06-02 13:18:48', NULL, 1),
(2083, 1, '193', 'Datos de la formulario', 'Datos de la formulario', NULL, '2009-06-03 13:21:44', '2009-06-03 13:21:44', NULL, 1),
(2084, 1, '194', 'de alquiler', 'de alquiler', NULL, '2009-06-03 13:22:55', '2009-06-03 13:22:55', NULL, 1),
(2085, 1, '195', 'de su familia', 'de su familia', NULL, '2009-06-03 13:23:00', '2009-06-03 13:23:00', NULL, 1),
(2086, 1, '196', 'de su propiedad', 'de su propiedad', NULL, '2009-06-03 13:23:03', '2009-06-03 13:23:03', NULL, 1),
(2087, 1, '197', 'por acceso a propiedad', 'por acceso a propiedad', NULL, '2009-06-02 13:20:32', '2009-06-02 13:20:32', NULL, 1),
(2088, 1, '198', 'por boda', 'por boda', NULL, '2009-06-02 13:13:40', '2009-06-02 13:13:40', NULL, 1),
(2089, 1, '199', 'por independencia', 'por independencia', NULL, '2009-06-02 13:15:02', '2009-06-02 13:15:02', NULL, 1),
(2090, 1, '200', 'por inversión', 'por inversión', NULL, '2009-06-02 13:15:11', '2009-06-02 13:15:11', NULL, 1),
(2091, 1, '201', 'por reposición', 'por reposición', NULL, '2009-06-02 13:15:20', '2009-06-02 13:15:20', NULL, 1),
(2092, 1, '202', 'de %1% a %2%', 'de %1% a %2%', NULL, '2009-06-03 13:22:51', '2009-06-03 13:22:51', NULL, 1),
(2093, 1, '203', 'menos de %1%', 'menos de %1%', NULL, '2009-06-03 16:26:16', '2009-06-03 16:26:16', NULL, 1),
(2094, 1, '204', '%1% por ciento', '%1% por ciento', NULL, '2009-06-02 12:32:18', '2009-06-02 12:32:18', NULL, 1),
(2095, 1, '205', 'más del %1% por ciento', 'más del %1% por ciento', NULL, '2009-06-03 16:18:11', '2009-06-03 16:18:11', NULL, 1),
(2096, 1, '206', 'amigos', 'amigos', NULL, '2009-06-02 12:41:19', '2009-06-02 12:41:19', NULL, 1),
(2097, 1, '207', 'folleto', 'folleto', NULL, '2009-06-03 15:55:03', '2009-06-03 15:55:03', NULL, 1),
(2098, 1, '208', 'prensa', 'prensa', NULL, '2009-06-02 13:15:30', '2009-06-02 13:15:30', NULL, 1),
(2099, 1, '209', 'publicaciones inmobiliarias', 'publicaciones inmobiliarias', NULL, '2009-06-02 13:10:36', '2009-06-02 13:10:36', NULL, 1),
(2100, 1, '210', 'radio', 'radio', NULL, '2009-06-02 13:10:57', '2009-06-02 13:10:57', NULL, 1),
(2101, 1, '211', 'visita obra', 'visita obra', NULL, '2009-06-02 13:00:00', '2009-06-02 13:00:00', NULL, 1),
(2102, 1, '212', 'valla', 'valla', NULL, '2009-06-02 13:01:28', '2009-06-02 13:01:28', NULL, 1),
(2103, 1, '213', 'otros', 'Otros', NULL, '2009-06-02 13:19:36', '2009-06-02 13:19:36', NULL, 1),
(2104, 1, '214', 'hombre', 'hombre', NULL, '2009-06-03 16:09:43', '2009-06-03 16:09:43', NULL, 1),
(2105, 1, '215', 'mujer', 'mujer', NULL, '2009-06-02 13:21:47', '2009-06-02 13:21:47', NULL, 1),
(2106, 1, '216', 'casado/a', 'casado/a', NULL, '2009-06-03 13:16:51', '2009-06-03 13:16:51', NULL, 1),
(2107, 1, '217', 'pareja', 'pareja', NULL, '2009-06-02 13:20:02', '2009-06-02 13:20:02', NULL, 1),
(2108, 1, '218', 'divorciado/a', 'divorciado/a', NULL, '2009-06-03 13:25:12', '2009-06-03 13:25:12', NULL, 1),
(2109, 1, '219', 'soltero/a', 'soltero/a', NULL, '2009-06-02 13:07:59', '2009-06-02 13:07:59', NULL, 1),
(2110, 1, '220', 'viudo/a', 'viudo/a', NULL, '2009-06-02 12:59:43', '2009-06-02 12:59:43', NULL, 1),
(2111, 1, '221', '[1] 1 persona|(1,4] %1% personas|(4,+Inf] más de 4 personas', '[1] 1 persona|(1,4] %1% personas|(4,+Inf] más de 4 personas', NULL, '2009-06-02 12:58:22', '2009-06-02 12:58:22', NULL, 1),
(2112, 1, '222', 'primer cuatrimestre', 'primer cuatrimestre', NULL, '2009-06-02 13:15:55', '2009-06-02 13:15:55', NULL, 1),
(2113, 1, '223', 'segundo cuatrimestre', 'segundo cuatrimestre', NULL, '2009-06-02 13:12:24', '2009-06-02 13:12:24', NULL, 1),
(2114, 1, '224', 'tercer cuatrimestre', 'tercer cuatrimestre', NULL, '2009-06-02 13:08:25', '2009-06-02 13:08:25', NULL, 1),
(2115, 1, '225', 'cuarto cuatrimestre', 'cuarto cuatrimestre', NULL, '2009-06-03 13:20:08', '2009-06-03 13:20:08', NULL, 1),
(2116, 1, '226', 'Marque si le interesa cualquier fuente de datos', 'Marque si le interesa cualquier fuente de datos', NULL, '2009-06-03 16:17:41', '2009-06-03 16:17:41', NULL, 1),
(2117, 1, '227', 'Marque si es un cliente especial', 'Marque si es un cliente especial', NULL, '2009-06-03 16:17:36', '2009-06-03 16:17:36', NULL, 1),
(2118, 1, '228', 'poco interesado', 'poco interesado', NULL, '2009-06-02 13:20:28', '2009-06-02 13:20:28', NULL, 1),
(2119, 1, '229', 'muy interesado', 'muy interesado', NULL, '2009-06-02 13:21:51', '2009-06-02 13:21:51', NULL, 1),
(2120, 1, '230', 'reservado', 'reservado', NULL, '2009-06-02 13:11:27', '2009-06-02 13:11:27', NULL, 1),
(2121, 1, '231', 'vendido', 'vendido', NULL, '2009-06-02 13:01:24', '2009-06-02 13:01:24', NULL, 1),
(2122, 1, '232', 'Registros de', 'Registros de', NULL, '2009-06-02 13:11:06', '2009-06-02 13:11:06', NULL, 1),
(2124, 1, '234', 'fecha', 'fecha', NULL, '2009-06-03 15:54:10', '2009-06-03 15:54:10', NULL, 1),
(2125, 1, '235', 'Crear registro', 'Crear registro', NULL, '2009-06-03 13:19:40', '2009-06-03 13:19:40', NULL, 1),
(2126, 1, '236', 'Nuevo registro', 'Nuevo registro', NULL, '2009-06-02 13:19:24', '2009-06-02 13:19:24', NULL, 1),
(2127, 1, '237', 'Filtros activados', 'Filtros activados', NULL, '2009-06-03 15:54:46', '2009-06-03 15:54:46', NULL, 1),
(2128, 1, '238', 'filtros', 'filtros', NULL, '2009-06-03 15:54:42', '2009-06-03 15:54:42', NULL, 1),
(2129, 1, '239', 'filtros de datos', 'filtros de datos', NULL, '2009-06-03 15:54:50', '2009-06-03 15:54:50', NULL, 1),
(2130, 1, '240', 'Tabla', 'Tabla', NULL, '2009-06-02 13:08:03', '2009-06-02 13:08:03', NULL, 1),
(2132, 1, '242', 'filtrar', 'filtrar', NULL, '2009-06-03 15:54:34', '2009-06-03 15:54:34', NULL, 1),
(2133, 1, '243', 'Crear nuevo registro', 'Crear nuevo registro', NULL, '2009-06-03 13:19:36', '2009-06-03 13:19:36', NULL, 1),
(2134, 1, '244', 'Exportar a Excel', 'Exportar a Excel', NULL, '2009-06-03 15:54:07', '2009-06-03 15:54:07', NULL, 1),
(2135, 1, '245', 'Volver', 'Volver', NULL, '2009-06-02 12:59:38', '2009-06-02 12:59:38', NULL, 1),
(2136, 1, '246', 'Lista de campos', 'Lista de campos', NULL, '2009-06-03 16:13:30', '2009-06-03 16:13:30', NULL, 1),
(2138, 1, '248', 'Formularios', 'Formularios', NULL, '2009-06-03 15:55:08', '2009-06-03 15:55:08', NULL, 1),
(2139, 1, '249', 'lista de formularios', 'lista de formularios', NULL, '2009-06-03 16:13:49', '2009-06-03 16:13:49', NULL, 1),
(2140, 1, '250', 'Por favor, sea lo más específico posible. ¡Gracias!', 'Por favor, sea lo más específico posible. ¡Gracias!', NULL, '2009-06-02 13:14:58', '2009-06-02 13:14:58', NULL, 1),
(2141, 1, '251', 'Indique su nombre', 'Indique su nombre', NULL, '2009-06-03 16:10:55', '2009-06-03 16:10:55', NULL, 1),
(2142, 1, '252', 'Indique su dirección de correo electrónico', 'Indique su dirección de correo electrónico', NULL, '2009-06-03 16:10:51', '2009-06-03 16:10:51', NULL, 1),
(2144, 1, '254', 'Describa el problema lo más detalladamente posible', 'Describa el problema lo más detalladamente posible', NULL, '2009-06-03 13:23:40', '2009-06-03 13:23:40', NULL, 1),
(2145, 1, '255', 'Enviar', 'Enviar', NULL, '2009-06-03 13:29:32', '2009-06-03 13:29:32', NULL, 1),
(2146, 1, '256', 'Información', 'Información', NULL, '2009-06-03 16:11:04', '2009-06-03 16:11:04', NULL, 1),
(2147, 1, '257', 'Contacto', 'Contacto', NULL, '2009-06-03 13:18:56', '2009-06-03 13:18:56', NULL, 1),
(2149, 1, '259', 'Versión %1%', 'Versión %1%', NULL, '2009-06-02 13:00:04', '2009-06-02 13:00:04', NULL, 1),
(2150, 1, '260', 'Informe acerca de un fallo', 'Informe acerca de un fallo', NULL, '2009-06-03 16:11:12', '2009-06-03 16:11:12', NULL, 1),
(2151, 1, '261', 'Por favor introduzca su nombre', 'Por favor introduzca su nombre', NULL, '2009-06-02 13:14:05', '2009-06-02 13:14:05', NULL, 1),
(2152, 1, '262', 'Por favor introduzca su dirección de correo electrónico', 'Por favor introduzca su dirección de correo electrónico', NULL, '2009-06-02 13:13:59', '2009-06-02 13:13:59', NULL, 1),
(2153, 1, '263', 'La dirección de correo debe ser correcta', 'La dirección de correo debe ser correcta', NULL, '2009-06-03 16:12:42', '2009-06-03 16:12:42', NULL, 1),
(2154, 1, '264', 'Por favor introduzca la página donde ha experimentado el problema', 'Por favor introduzca la página donde ha experimentado el problema', NULL, '2009-06-02 13:13:47', '2009-06-02 13:13:47', NULL, 1),
(2155, 1, '265', 'Por favor introduzca una descripción del problema', 'Por favor introduzca una descripción del problema', NULL, '2009-06-02 13:14:15', '2009-06-02 13:14:15', NULL, 1),
(2157, 1, '267', 'todas', 'todas', NULL, '2009-06-03 16:28:47', '2009-06-03 16:28:47', NULL, 1),
(2158, 1, '268', 'Si no marca esta opción el usuario solo podrá ver aquellos registros que haya creado', 'Si no marca esta opción el usuario solo podrá ver aquellos registros que haya creado', NULL, '2009-06-02 13:07:22', '2009-06-02 13:07:22', NULL, 1),
(2159, 1, '269', 'Editar alcance', 'Editar alcance', NULL, '2009-06-03 13:26:05', '2009-06-03 13:26:05', NULL, 1),
(2160, 1, '270', 'lista de usuarios', 'lista de usuarios', NULL, '2009-06-03 16:16:07', '2009-06-03 16:16:07', NULL, 1),
(2161, 1, '271', 'Crear una nueva regla', 'Crear una nueva regla', NULL, '2009-06-03 13:19:50', '2009-06-03 13:19:50', NULL, 1),
(2162, 1, '272', 'Ver alcance del usuario', 'Ver alcance del usuario', NULL, '2009-06-02 12:57:33', '2009-06-02 12:57:33', NULL, 1),
(2163, 1, '273', 'Datos del alcance del usuario', 'Datos del alcance del usuario', NULL, '2009-06-03 13:21:54', '2009-06-03 13:21:54', NULL, 1),
(2165, 1, '275', 'Categorías de informes a las que tiene acceso', 'Categorías de informes a las que tiene acceso', NULL, '2009-06-03 13:16:59', '2009-06-03 13:16:59', NULL, 1),
(2168, 1, '278', 'e-mail', 'e-mail', NULL, '2009-06-03 13:25:21', '2009-06-03 13:25:21', NULL, 1),
(2171, 1, '281', 'Id usuario:', 'Id usuario:', NULL, '2009-06-03 16:09:59', '2009-06-03 16:09:59', NULL, 1),
(2172, 1, '282', 'Usuario:', 'Usuario:', NULL, '2009-06-02 13:01:46', '2009-06-02 13:01:46', NULL, 1),
(2173, 1, '283', 'Primer apellido:', 'Primer apellido:', NULL, '2009-06-02 13:15:51', '2009-06-02 13:15:51', NULL, 1),
(2174, 1, '284', 'Email:', 'Email:', NULL, '2009-06-03 13:29:02', '2009-06-03 13:29:02', NULL, 1),
(2177, 1, '287', 'Por favor, introduce un nombre', 'Por favor, introduce un nombre', NULL, '2009-06-02 13:14:43', '2009-06-02 13:14:43', NULL, 1),
(2178, 1, '288', 'Por favor, es necesario el dato.', 'Por favor, es necesario el dato.', NULL, '2009-06-02 13:14:25', '2009-06-02 13:14:25', NULL, 1),
(2179, 1, '289', 'Este campo es demasiado corto (mí­nimo 2 caracteres)', 'Este campo es demasiado corto (mí­nimo 2 caracteres)', NULL, '2009-06-03 15:53:39', '2009-06-03 15:53:39', NULL, 1),
(2180, 1, '290', 'Este campo es demasiado largo (máximo 100 caracteres)', 'Este campo es demasiado largo (máximo 100 caracteres)', NULL, '2009-06-03 15:53:49', '2009-06-03 15:53:49', NULL, 1),
(2181, 1, '291', 'Editar campo', 'Editar campo', NULL, '2009-06-03 13:26:09', '2009-06-03 13:26:09', NULL, 1),
(2182, 1, '292', 'Datos del elemento', 'Datos del elemento', NULL, '2009-06-03 13:22:09', '2009-06-03 13:22:09', NULL, 1),
(2183, 1, '293', 'Puede mostrar un texto de ayuda como este para la comprensión del elemento', 'Puede mostrar un texto de ayuda como este para la comprensión del elemento', NULL, '2009-06-02 13:10:47', '2009-06-02 13:10:47', NULL, 1),
(2184, 1, '294', 'Active la casilla si quiere que el usuario pueda introducir un texto descriptivo', 'Active la casilla si quiere que el usuario pueda introducir un texto descriptivo', NULL, '2009-06-02 12:39:31', '2009-06-02 12:39:31', NULL, 1),
(2185, 1, '295', 'Lista de elementos', 'Lista de elementos', NULL, '2009-06-03 16:13:39', '2009-06-03 16:13:39', NULL, 1),
(2186, 1, '296', 'Empresa a la que pertenece', 'Empresa a la que pertenece', NULL, '2009-06-03 13:29:15', '2009-06-03 13:29:15', NULL, 1),
(2187, 1, '297', 'Datos del campo', 'Datos del campo', NULL, '2009-06-03 13:21:59', '2009-06-03 13:21:59', NULL, 1),
(2188, 1, '298', 'Editar modelo de campos', 'Editar modelo de campos', NULL, '2009-06-03 13:28:40', '2009-06-03 13:28:40', NULL, 1),
(2189, 1, '299', 'Si es general se mostrará en todas las tablas', 'Si es general, se mostrará en todas las tablas', NULL, '2009-06-02 13:07:09', '2009-06-02 13:07:09', NULL, 1),
(2190, 1, '300', 'Este campo identifica al formulario', 'Este campo identifica al formulario', NULL, '2009-06-03 15:53:53', '2009-06-03 15:53:53', NULL, 1),
(2191, 1, '301', 'Indica que este campo no puede estar vacio a la hora de introducirse un valor.', 'Indica que este campo no puede estar vacio a la hora de introducirse un valor.', NULL, '2009-06-03 16:10:04', '2009-06-03 16:10:04', NULL, 1),
(2192, 1, '302', 'Características del campo', 'Características del campo', NULL, '2009-06-03 13:16:42', '2009-06-03 13:16:42', NULL, 1),
(2193, 1, '303', 'Marque esta opción si quiere que puedan seleccionarse varios elementos de la lista', 'Marque esta opción si quiere que puedan seleccionarse varios elementos de la lista', NULL, '2009-06-03 16:17:26', '2009-06-03 16:17:26', NULL, 1),
(2194, 1, '304', 'Indique el tipo de los elementos de la lista', 'Indique el tipo de los elementos de la lista', NULL, '2009-06-03 16:10:12', '2009-06-03 16:10:12', NULL, 1),
(2195, 1, '305', 'sin definir', 'Sin definir', NULL, '2009-06-02 13:07:47', '2009-06-02 13:07:47', NULL, 1),
(2196, 1, '306', 'Indique el tipo de unidad. Sólo para el tipo de elementos Rangos de Valores', 'Indique el tipo de unidad. Sólo para el tipo de elementos Rangos de Valores', NULL, '2009-06-03 16:10:26', '2009-06-03 16:10:26', NULL, 1),
(2197, 1, '307', 'Indique el tipo de periodicidad', 'Indique el tipo de periodicidad', NULL, '2009-06-03 16:10:17', '2009-06-03 16:10:17', NULL, 1),
(2198, 1, '308', 'Indique la tabla a la que referencia', 'Indique la tabla a la que referencia', NULL, '2009-06-03 16:10:35', '2009-06-03 16:10:35', NULL, 1),
(2199, 1, '309', 'Indique el valor por defecto del campo', 'Indique el valor por defecto del campo', NULL, '2009-06-03 16:10:31', '2009-06-03 16:10:31', NULL, 1),
(2200, 1, '310', 'Indique si quiere mostrar en los registros de la tabla padre un listado de los registros de la tabla actual', 'Indique si quiere mostrar en los registros de la tabla padre un listado de los registros de la tabla actual', NULL, '2009-06-03 16:10:39', '2009-06-03 16:10:39', NULL, 1),
(2201, 1, '311', 'Indique el objeto al que se referencia', 'Indique el objeto al que se referencia', NULL, '2009-06-03 16:10:08', '2009-06-03 16:10:08', NULL, 1),
(2202, 1, '312', 'Día en curso', 'Día en curso', NULL, '2009-06-03 13:22:38', '2009-06-03 13:22:38', NULL, 1),
(2203, 1, '313', 'Día anterior', 'Día anterior', NULL, '2009-06-03 13:22:31', '2009-06-03 13:22:31', NULL, 1),
(2204, 1, '314', 'Día Posterior', 'Día Posterior', NULL, '2009-06-03 13:22:45', '2009-06-03 13:22:45', NULL, 1),
(2205, 1, '315', 'Primero Mes', 'Primero de Mes', NULL, '2009-06-02 13:10:24', '2009-06-02 13:10:24', NULL, 1),
(2206, 1, '316', 'Ultimo Mes', 'Ultimo Mes', NULL, '2009-06-02 13:02:18', '2009-06-02 13:02:18', NULL, 1),
(2207, 1, '317', 'Primero Año', 'Primero Año', NULL, '2009-06-02 13:16:06', '2009-06-02 13:16:06', NULL, 1),
(2208, 1, '318', 'Ultimo Año', 'Ultimo Año', NULL, '2009-06-02 13:02:28', '2009-06-02 13:02:28', NULL, 1),
(2213, 1, '323', 'La formulario modelo ha cambiado', 'La formulario modelo ha cambiado', NULL, '2009-06-03 16:12:46', '2009-06-03 16:12:46', NULL, 1),
(2659, 1, '364', '¿Quiere borrar este mensaje? También se borrarán las copias enviadas a los destinatarios', '¿Quiere borrar este mensaje? También se borrarán las copias enviadas a los destinatarios', NULL, '2009-06-02 13:28:32', '2009-06-02 13:28:32', NULL, 1),
(2215, 1, '325', 'Los cambios de la formulario modelo serán guardados sin alterar los registros', 'Los cambios de la formulario modelo serán guardados sin alterar los registros', NULL, '2009-06-03 16:16:31', '2009-06-03 16:16:31', NULL, 1),
(2655, 1, '360', 'Actualizar campos', 'Actualizar campos', NULL, '2009-06-02 13:25:02', '2009-06-02 13:25:02', NULL, 1),
(2217, 1, '327', 'Los campos alterados serán borrados de aquellos registros en las que aparezcan', 'Los campos alterados serán borrados de aquellos registros en las que aparezcan', NULL, '2009-06-03 16:17:00', '2009-06-03 16:17:00', NULL, 1),
(2658, 1, '363', 'Borrar completamente', 'Borrar completamente', NULL, '2009-06-03 13:16:09', '2009-06-03 13:16:09', NULL, 1),
(2657, 1, '362', 'Añadir elemento', 'Añadir elemento', NULL, '2009-06-02 13:24:04', '2009-06-02 13:24:04', NULL, 1),
(2654, 1, '359', 'Añadir nuevo campo', 'Añadir nuevo campo', NULL, '2009-06-02 13:25:13', '2009-06-02 13:25:13', NULL, 1),
(2222, 1, '332', 'ha sido alterado', 'ha sido alterado', NULL, '2009-06-03 16:09:23', '2009-06-03 16:09:23', NULL, 1),
(2224, 1, '334', 'Características', 'Características', NULL, '2009-06-03 13:16:34', '2009-06-03 13:16:34', NULL, 1),
(2225, 1, '335', 'Texto de ayuda. Déjelo vacío para que no aparezca.', 'Texto de ayuda. Déjelo vacío para que no aparezca.', NULL, '2009-06-02 13:04:05', '2009-06-02 13:04:05', NULL, 1),
(2226, 1, '336', 'Los campos han cambiado', 'Los campos han cambiado', NULL, '2009-06-03 16:17:07', '2009-06-03 16:17:07', NULL, 1),
(2228, 1, '338', 'Los cambios en los campos serán guardados sin alterar los campos de los registros', 'Los cambios en los campos serán guardados sin alterar los campos de los registros', NULL, '2009-06-03 16:16:43', '2009-06-03 16:16:43', NULL, 1),
(2640, 1, '345', '¿Dónde ha experimentado el problema?', '¿Dónde ha experimentado el problema?', NULL, '2009-06-02 13:27:23', '2009-06-02 13:27:23', NULL, 1),
(2230, 1, '340', 'Los campos alterados serán borrados de aquellas registros en las que aparezcan', 'Los campos alterados serán borrados de aquellas registros en las que aparezcan', NULL, '2009-06-03 16:16:52', '2009-06-03 16:16:52', NULL, 1),
(2639, 1, '344', 'Última actualización', 'Última actualización', NULL, '2009-06-02 13:26:46', '2009-06-02 13:26:46', NULL, 1),
(2234, 1, '344', 'Editar elemento del campo', 'Editar elemento del campo', NULL, '2009-06-03 13:26:22', '2009-06-03 13:26:22', NULL, 1),
(2235, 1, '345', 'Código HTML del formulario externo', 'Código HTML del formulario externo', NULL, '2009-06-03 13:18:21', '2009-06-03 13:18:21', NULL, 1),
(2237, 1, '347', 'Pertenece a', 'Pertenece a', NULL, '2009-06-02 13:20:12', '2009-06-02 13:20:12', NULL, 1),
(2238, 1, '348', 'Guardar y editar', 'Guardar y editar', NULL, '2009-06-03 15:56:56', '2009-06-03 15:56:56', NULL, 1),
(2239, 1, '349', 'Editar elementos del campo', 'Editar elementos del campo', NULL, '2009-06-03 13:26:27', '2009-06-03 13:26:27', NULL, 1),
(2240, 1, '350', 'Código HTML', 'Código HTML', NULL, '2009-06-03 13:18:14', '2009-06-03 13:18:14', NULL, 1),
(2241, 1, '351', 'Este código contiene los campos necesarios para introducir nuevos clientes junto con sus formularios', 'Este código contiene los campos necesarios para introducir nuevos clientes junto con sus formularios', NULL, '2009-06-03 15:54:02', '2009-06-03 15:54:02', NULL, 1),
(2242, 1, '352', 'Marque esta casilla si quiere que el mensaje se envía en una fecha determinada', 'Marque esta casilla si quiere que el mensaje se envía en una fecha determinada', NULL, '2009-06-03 16:17:17', '2009-06-03 16:17:17', NULL, 1),
(2243, 1, '353', 'Lista de destinatarios', 'Lista de destinatarios', NULL, '2009-06-03 16:13:34', '2009-06-03 16:13:34', NULL, 1),
(2244, 1, '354', 'borrar completamente', 'Borrar completamente', NULL, '2009-06-02 12:51:08', '2009-06-02 12:51:08', NULL, 1),
(2632, 1, '337', 'Acciones', 'Acciones', NULL, '2009-06-02 13:25:48', '2009-06-02 13:25:48', NULL, 1),
(2246, 1, '356', 'borrar copia recibida', 'Borrar copia recibida', NULL, '2009-06-02 12:51:19', '2009-06-02 12:51:19', NULL, 1),
(2630, 1, '335', 'Último', 'Último', NULL, '2009-06-03 13:15:50', '2009-06-03 13:15:50', NULL, 1),
(2248, 1, '358', 'Leer', 'Leer', NULL, '2009-06-03 16:13:03', '2009-06-03 16:13:03', NULL, 1),
(2249, 1, '359', 'Enviar mensaje', 'Enviar mensaje', NULL, '2009-06-03 13:29:36', '2009-06-03 13:29:36', NULL, 1),
(2251, 1, '361', 'enviados a', 'enviados a', NULL, '2009-06-03 13:29:24', '2009-06-03 13:29:24', NULL, 1),
(2252, 1, '362', 'asunto', 'asunto', NULL, '2009-06-02 12:43:21', '2009-06-02 12:43:21', NULL, 1),
(2253, 1, '363', 'reiniciar', 'Reiniciar', NULL, '2009-06-02 13:11:22', '2009-06-02 13:11:22', NULL, 1),
(2254, 1, '364', 'enviados por', 'enviados por', NULL, '2009-06-03 13:29:28', '2009-06-03 13:29:28', NULL, 1),
(2255, 1, '365', 'leido', 'leido', NULL, '2009-06-03 16:13:12', '2009-06-03 16:13:12', NULL, 1),
(2256, 1, '366', 'Leer mensaje', 'Leer mensaje', NULL, '2009-06-03 16:13:07', '2009-06-03 16:13:07', NULL, 1),
(2258, 1, '368', 'Responder', 'Responder', NULL, '2009-06-02 13:11:39', '2009-06-02 13:11:39', NULL, 1),
(2259, 1, '369', 'Bandeja de salida', 'Bandeja de salida', NULL, '2009-06-02 12:48:54', '2009-06-02 12:48:54', NULL, 1),
(2631, 1, '336', '¿Quiere borrar este objeto?', '¿Quiere borrar este objeto?', NULL, '2009-06-02 13:28:39', '2009-06-02 13:28:39', NULL, 1),
(2629, 1, '334', '© 2009 ESLE Elkartea', '© 2009 ESLE Elkartea', NULL, '2009-06-02 12:56:57', '2009-06-02 12:56:57', NULL, 1),
(2638, 1, '343', 'Añadir registro a ', 'Añadir registro a ', NULL, '2009-06-02 13:24:24', '2009-06-02 13:24:24', NULL, 1),
(2647, 1, '352', '¿Desea des-borrar este objeto?', '¿Desea des-borrar este objeto?', NULL, '2009-06-02 13:27:54', '2009-06-02 13:27:54', NULL, 1),
(2662, 1, '367', '¿Quiere borrar este mensaje?', '¿Quiere borrar este mensaje?', NULL, '2009-06-02 13:28:17', '2009-06-02 13:28:17', NULL, 1),
(2641, 1, '346', 'Aplicación', 'Aplicación', NULL, '2009-06-02 13:26:12', '2009-06-02 13:26:12', NULL, 1),
(2642, 1, '347', 'Añadir nueva regla', 'Añadir nueva regla', NULL, '2009-06-02 13:24:09', '2009-06-02 13:24:09', NULL, 1),
(2643, 1, '348', 'Alcance', 'Alcance', NULL, '2009-06-02 13:25:27', '2009-06-02 13:25:27', NULL, 1),
(2644, 1, '349', 'Última visita', 'Última visita', NULL, '2009-06-02 13:26:32', '2009-06-02 13:26:32', NULL, 1),
(2645, 1, '350', 'Última visita:', 'Última visita:', NULL, '2009-06-02 13:26:37', '2009-06-02 13:26:37', NULL, 1),
(2660, 1, '365', '¿Quiere borrar esta copia? El mensaje original se mantendrá intacto', '¿Quiere borrar esta copia? El mensaje original se mantendrá intacto', NULL, '2009-06-02 13:28:12', '2009-06-02 13:28:12', NULL, 1),
(2656, 1, '361', 'Consolidar campos', 'Consolidar campos', NULL, '2009-06-03 13:18:47', '2009-06-03 13:18:47', NULL, 1),
(2653, 1, '358', '¿Desea continuar con la consolidación?', '¿Desea continuar con la consolidación?', NULL, '2009-06-02 13:27:47', '2009-06-02 13:27:47', NULL, 1),
(2650, 1, '355', 'Actualizar formulario modelo', 'Actualizar formulario modelo', NULL, '2009-06-02 13:25:06', '2009-06-02 13:25:06', NULL, 1),
(2651, 1, '356', 'Consolidar formularios', 'Consolidar formularios', NULL, '2009-06-03 13:18:51', '2009-06-03 13:18:51', NULL, 1),
(2652, 1, '357', '¿Desea continuar con la actualización?', '', NULL, '2009-06-02 13:27:37', '2009-06-02 13:27:37', NULL, 0),
(2633, 1, '338', '¿Desea borrar este objeto?', '¿Desea borrar este objeto?', NULL, '2009-06-02 13:27:30', '2009-06-02 13:27:30', NULL, 1),
(2634, 1, '339', 'Acción', 'Acción', NULL, '2009-06-02 12:56:45', '2009-06-02 12:56:45', NULL, 1),
(2635, 1, '340', 'Añadir registro', 'Añadir registro', NULL, '2009-06-02 13:24:16', '2009-06-02 13:24:16', NULL, 1),
(2637, 1, '342', '¿Desea duplicar este objeto?', '¿Desea duplicar este objeto?', NULL, '2009-06-02 13:28:00', '2009-06-02 13:28:00', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `id_idioma` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `usuario` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clave` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dni` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domicilio` text COLLATE utf8_unicode_ci,
  `poblacion` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cp` int(9) DEFAULT NULL,
  `id_provincia` int(11) DEFAULT NULL,
  `pais` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movil` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ultima_visita` datetime DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_key` text COLLATE utf8_unicode_ci,
  `es_externo` tinyint(4) DEFAULT NULL,
  `alerta_email` tinyint(4) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `fecha_borrado` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `FI_idioma_usuario` (`id_idioma`),
  KEY `FI_usuario_provincia` (`id_provincia`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `id_idioma`, `usuario`, `clave`, `nombre`, `apellido1`, `apellido2`, `dni`, `domicilio`, `poblacion`, `cp`, `id_provincia`, `pais`, `movil`, `telefono`, `fax`, `ultima_visita`, `email`, `es_externo`, `alerta_email`, `created_at`, `updated_at`, `fecha_borrado`) VALUES
(2, '1', 'admin', '', 'Administrador', 'Admin', 'tryj', 'jghfkgh', 'jghkhjg', 'jghkjhk', 0, 1, '', 'jghk', 'jghk', 'jghk', '2010-09-10 16:19:16', '', NULL, 0, '2007-08-31 08:36:56', '2010-09-10 16:19:16', NULL),
(1, '1', 'Invitado', '', 'Invitado', 'invitado', 'invitado', '', '', '', 0, 0, '', '', NULL, NULL, '2010-09-14 16:47:02', '', NULL, 0, '2007-08-31 09:15:37', '2010-09-14 16:47:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usuario_grupo`
--

DROP TABLE IF EXISTS `usuario_grupo`;
CREATE TABLE IF NOT EXISTS `usuario_grupo` (
  `id_usuario` int(11) NOT NULL,
  `id_grupo` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_grupo`),
  KEY `FI_grupo_usuario_grupo` (`id_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario_grupo`
--

INSERT INTO `usuario_grupo` (`id_usuario`, `id_grupo`) VALUES
(1, 2),
(2, 1);
