<?php

sfConfig::set('sf_lightwindow_js_dir',        '/sfLightWindowPlugin/js/');
sfConfig::set('sf_lightwindow_css_dir',       '/sfLightWindowPlugin/css/');
sfConfig::set('sf_lightwindow_prototype_dir', '/sfLightWindowPlugin/js/');

?>