<?php

sfConfig::set('sf_csstabs_config_tabs', SF_ROOT_DIR.DIRECTORY_SEPARATOR.'plugins'.DIRECTORY_SEPARATOR.'sfCssTabsPlugin'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR);