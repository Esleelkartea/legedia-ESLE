<?

phpinfo();

?>