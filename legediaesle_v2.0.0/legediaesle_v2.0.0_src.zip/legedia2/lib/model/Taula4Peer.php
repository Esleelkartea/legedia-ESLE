<?php

class Taula4Peer extends BaseTaula4Peer
{
}
