<?php

/**
 * Subclass for representing a row from the 'mensaje_destino' table.
 *
 * 
 *
 * @package lib.model
 */ 
class MensajeDestino extends BaseMensajeDestino
{
  public function save(PropelPDO $con = null)
	{

    parent::save($con);
  }
}

