<?php

/**
 * Subclass for performing query and update operations on the 'grupo_modulo' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GrupoModuloPeer extends BaseGrupoModuloPeer
{
}
