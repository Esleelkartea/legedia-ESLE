<?php

class Taula3 extends BaseTaula3
{
}
