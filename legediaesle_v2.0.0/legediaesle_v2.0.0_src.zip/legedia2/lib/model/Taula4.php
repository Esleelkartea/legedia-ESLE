<?php

class Taula4 extends BaseTaula4
{
}
