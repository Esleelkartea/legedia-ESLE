<?php

/**
 * Subclass for representing a row from the 'grupo_modulo' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GrupoModulo extends BaseGrupoModulo
{
}
