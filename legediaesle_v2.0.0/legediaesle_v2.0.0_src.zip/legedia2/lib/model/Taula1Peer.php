<?php

class Taula1Peer extends BaseTaula1Peer
{
}
