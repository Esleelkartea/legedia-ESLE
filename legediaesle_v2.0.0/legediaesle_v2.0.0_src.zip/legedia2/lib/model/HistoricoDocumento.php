<?php

class HistoricoDocumento extends BaseHistoricoDocumento
{
}
