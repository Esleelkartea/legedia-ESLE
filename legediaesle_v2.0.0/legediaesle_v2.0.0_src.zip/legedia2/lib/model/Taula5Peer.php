<?php

class Taula5Peer extends BaseTaula5Peer
{
}
