<?php

/**
 * Subclass for performing query and update operations on the 'item' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ItemPeer extends BaseItemPeer
{
}
