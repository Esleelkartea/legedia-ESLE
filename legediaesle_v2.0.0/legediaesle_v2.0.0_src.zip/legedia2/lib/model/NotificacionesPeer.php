<?php

class NotificacionesPeer extends BaseNotificacionesPeer
{
}
