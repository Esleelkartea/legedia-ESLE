<?php

class Taula5 extends BaseTaula5
{
}
