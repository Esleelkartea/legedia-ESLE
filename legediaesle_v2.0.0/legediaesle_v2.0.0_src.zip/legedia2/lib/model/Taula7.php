<?php

class Taula7 extends BaseTaula7
{
}
