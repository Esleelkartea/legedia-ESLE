<?php

/**
 * Subclass for representing a row from the 'alcance' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Alcance extends BaseAlcance
{
}
