<?php

/**
 * Subclass for performing query and update operations on the 'sesion_log' table.
 *
 * 
 *
 * @package lib.model
 */ 
class SesionLogPeer extends BaseSesionLogPeer
{
}
