<?php

class Taula7Peer extends BaseTaula7Peer
{
}
