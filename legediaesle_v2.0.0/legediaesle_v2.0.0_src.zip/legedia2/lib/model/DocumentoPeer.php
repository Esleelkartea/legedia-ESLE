<?php

class DocumentoPeer extends BaseDocumentoPeer
{
}
