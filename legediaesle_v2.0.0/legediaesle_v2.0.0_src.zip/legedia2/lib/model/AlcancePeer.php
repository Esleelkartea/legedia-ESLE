<?php

/**
 * Subclass for performing query and update operations on the 'alcance' table.
 *
 * 
 *
 * @package lib.model
 */ 
class AlcancePeer extends BaseAlcancePeer
{
}
