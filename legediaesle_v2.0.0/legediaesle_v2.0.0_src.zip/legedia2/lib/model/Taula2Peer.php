<?php

class Taula2Peer extends BaseTaula2Peer
{
}
