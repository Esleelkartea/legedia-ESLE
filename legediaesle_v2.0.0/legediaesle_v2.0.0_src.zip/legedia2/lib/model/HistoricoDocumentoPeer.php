<?php

class HistoricoDocumentoPeer extends BaseHistoricoDocumentoPeer
{
}
