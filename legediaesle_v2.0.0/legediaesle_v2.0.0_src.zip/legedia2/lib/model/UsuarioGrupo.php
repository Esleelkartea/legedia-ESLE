<?php

/**
 * Subclass for representing a row from the 'usuario_grupo' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UsuarioGrupo extends BaseUsuarioGrupo
{
}
