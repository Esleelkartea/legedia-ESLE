<?php

class Documento extends BaseDocumento
{
}
