<?php

class Taula2 extends BaseTaula2
{
}
