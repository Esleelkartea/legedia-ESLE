<?php

/**
 * Subclass for representing a row from the 'provincia' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Provincia extends BaseProvincia
{
  public function __toString()
  {
    return $this->getNombre();
  }
}
