<?php

class Taula3Peer extends BaseTaula3Peer
{
}
