<?php

/**
 * Subclass for performing query and update operations on the 'mensaje_destino' table.
 *
 * 
 *
 * @package lib.model
 */ 
class MensajeDestinoPeer extends BaseMensajeDestinoPeer
{
}
