<?php

/**
 * Subclass for representing a row from the 'rel_campo_tabla' table.
 *
 * 
 *
 * @package lib.model
 */ 
class RelCampoTabla extends BaseRelCampoTabla
{
}
