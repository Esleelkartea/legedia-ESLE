<?php

/**
 * Subclass for performing query and update operations on the 'rel_campo_tabla' table.
 *
 * 
 *
 * @package lib.model
 */ 
class RelCampoTablaPeer extends BaseRelCampoTablaPeer
{
}
