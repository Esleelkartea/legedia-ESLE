<?php

/**
 * Subclass for performing query and update operations on the 'usuario_grupo' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UsuarioGrupoPeer extends BaseUsuarioGrupoPeer
{
}
