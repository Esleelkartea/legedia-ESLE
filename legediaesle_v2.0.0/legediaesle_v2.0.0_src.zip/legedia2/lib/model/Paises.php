<?php

class Paises extends BasePaises
{
}
