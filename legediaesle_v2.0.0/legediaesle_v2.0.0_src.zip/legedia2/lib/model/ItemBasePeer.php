<?php

/**
 * Subclass for performing query and update operations on the 'item_base' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ItemBasePeer extends BaseItemBasePeer
{
}
