<?php

class PaisesPeer extends BasePaisesPeer
{
}
