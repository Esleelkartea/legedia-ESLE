<?php

/**
 * Subclass for performing query and update operations on the 'sesion' table.
 *
 * 
 *
 * @package lib.model
 */ 
class SesionPeer extends BaseSesionPeer
{
}
